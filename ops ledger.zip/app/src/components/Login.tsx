import { useState } from 'react';
import { useAuth, type UserRole } from '@/contexts/AuthContext';
import { Building2, Users, User, Shield, Eye, EyeOff } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
}

export function Login({ onLogin }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('admin');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();

  const roles: { value: UserRole; label: string; icon: React.ReactNode; description: string }[] = [
    { 
      value: 'admin', 
      label: 'Administrator', 
      icon: <Shield className="w-5 h-5" />,
      description: 'Full system access'
    },
    { 
      value: 'staff', 
      label: 'Operations Staff', 
      icon: <Users className="w-5 h-5" />,
      description: 'Project & task management'
    },
    { 
      value: 'client', 
      label: 'Client', 
      icon: <User className="w-5 h-5" />,
      description: 'Project tracking & requests'
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      await login(email, password, selectedRole);
      onLogin();
    } catch (err) {
      setError('Invalid credentials. Use any email with password "demo"');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50">
      {/* Background Pattern */}
      <div className="fixed inset-0 grid-pattern opacity-20" />
      
      {/* Gradient Overlay */}
      <div 
        className="fixed inset-0"
        style={{
          background: 'radial-gradient(ellipse at 50% 0%, rgba(59, 130, 246, 0.08) 0%, transparent 50%)'
        }}
      />

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-[var(--accent)] flex items-center justify-center shadow-lg">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <span className="font-display text-2xl font-bold tracking-tight text-[var(--text-primary)]">
              OpsLedger
            </span>
          </div>
          <p className="text-[var(--text-muted)] text-sm">
            Internal Operations Platform
          </p>
        </div>

        {/* Login Card */}
        <div className="card p-8 bg-white">
          <h1 className="text-xl font-semibold text-[var(--text-primary)] mb-6 text-center">
            Sign In
          </h1>

          {error && (
            <div className="mb-6 p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email */}
            <div>
              <label className="section-label block mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-muted)] transition-colors"
                required
              />
            </div>

            {/* Password */}
            <div>
              <label className="section-label block mb-2">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 pr-12 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-muted)] transition-colors"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-[var(--text-primary)] transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <p className="mt-1 text-xs text-[var(--text-muted)]">
                Use password: <span className="text-[var(--accent)] font-medium">demo</span>
              </p>
            </div>

            {/* Role Selection */}
            <div>
              <label className="section-label block mb-3">Select Role</label>
              <div className="space-y-2">
                {roles.map((role) => (
                  <button
                    key={role.value}
                    type="button"
                    onClick={() => setSelectedRole(role.value)}
                    className={`w-full flex items-center gap-4 p-4 rounded-lg border transition-all ${
                      selectedRole === role.value
                        ? 'border-[var(--accent)] bg-[var(--accent-muted)]'
                        : 'border-[var(--border)] hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className={`${
                      selectedRole === role.value ? 'text-[var(--accent)]' : 'text-[var(--text-muted)]'
                    }`}>
                      {role.icon}
                    </div>
                    <div className="text-left">
                      <div className={`font-medium ${
                        selectedRole === role.value ? 'text-[var(--accent)]' : 'text-[var(--text-primary)]'
                      }`}>
                        {role.label}
                      </div>
                      <div className="text-xs text-[var(--text-muted)]">
                        {role.description}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full btn-primary py-3 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          {/* Demo Credentials */}
          <div className="mt-6 pt-6 border-t border-[var(--border)]">
            <p className="text-xs text-[var(--text-muted)] text-center mb-2">
              Demo Credentials
            </p>
            <div className="text-xs text-[var(--text-secondary)] text-center space-y-1">
              <p>admin@opsledger.com / staff@opsledger.com / client@opsledger.com</p>
              <p>Password: <span className="text-[var(--accent)] font-medium">demo</span></p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-[var(--text-muted)] mt-6">
          © 2024 OpsLedger. All rights reserved.
        </p>
      </div>
    </div>
  );
}
