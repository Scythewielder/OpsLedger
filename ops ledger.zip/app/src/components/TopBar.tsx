import { useTheme } from '@/contexts/ThemeContext';
import { useLayout } from '@/contexts/LayoutContext';
import { 
  Bell, 
  Search, 
  Sun, 
  Moon,
  Grid3X3,
  List,
  LayoutGrid,
  AlignJustify,
  Maximize2,
  Minimize2
} from 'lucide-react';

interface TopBarProps {
  title: string;
  subtitle?: string;
  showLayoutSwitcher?: boolean;
}

export function TopBar({ title, subtitle, showLayoutSwitcher = true }: TopBarProps) {
  const { theme, toggleTheme } = useTheme();
  const { layout, setLayout, density, setDensity, sidebarCollapsed } = useLayout();

  const layoutOptions = [
    { id: 'grid', icon: <Grid3X3 className="w-4 h-4" />, label: 'Grid' },
    { id: 'flex', icon: <LayoutGrid className="w-4 h-4" />, label: 'Flex' },
    { id: 'list', icon: <List className="w-4 h-4" />, label: 'List' },
  ] as const;

  const densityOptions = [
    { id: 'compact', icon: <Minimize2 className="w-4 h-4" />, label: 'Compact' },
    { id: 'comfortable', icon: <AlignJustify className="w-4 h-4" />, label: 'Normal' },
    { id: 'spacious', icon: <Maximize2 className="w-4 h-4" />, label: 'Spacious' },
  ] as const;

  return (
    <header 
      className="h-16 bg-white border-b border-[var(--border)] flex items-center justify-between px-6 sticky top-0 z-30"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Title */}
      <div>
        <h1 className="font-semibold text-lg text-[var(--text-primary)]">
          {title}
        </h1>
        {subtitle && (
          <p className="text-xs text-[var(--text-muted)]">{subtitle}</p>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)]">
          <Search className="w-4 h-4 text-[var(--text-muted)]" />
          <input
            type="text"
            placeholder="Search..."
            className="bg-transparent text-sm text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none w-48"
          />
        </div>

        {/* Layout Switcher */}
        {showLayoutSwitcher && (
          <>
            {/* Layout Type */}
            <div className="flex items-center gap-1 p-1 bg-gray-50 rounded-lg border border-[var(--border)]">
              {layoutOptions.map((option) => (
                <button
                  key={option.id}
                  onClick={() => setLayout(option.id as typeof layout)}
                  className={`p-2 rounded-md transition-all ${
                    layout === option.id 
                      ? 'bg-white text-[var(--accent)] shadow-sm' 
                      : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
                  }`}
                  title={option.label}
                >
                  {option.icon}
                </button>
              ))}
            </div>

            {/* Density */}
            <div className="flex items-center gap-1 p-1 bg-gray-50 rounded-lg border border-[var(--border)]">
              {densityOptions.map((option) => (
                <button
                  key={option.id}
                  onClick={() => setDensity(option.id as typeof density)}
                  className={`p-2 rounded-md transition-all ${
                    density === option.id 
                      ? 'bg-white text-[var(--accent)] shadow-sm' 
                      : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
                  }`}
                  title={option.label}
                >
                  {option.icon}
                </button>
              ))}
            </div>
          </>
        )}

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="w-9 h-9 rounded-lg border border-[var(--border)] flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--accent)] hover:border-[var(--accent)] transition-all"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Notifications */}
        <button className="relative w-9 h-9 rounded-lg border border-[var(--border)] flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:border-gray-300 transition-all">
          <Bell className="w-4 h-4" />
          <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[var(--accent)] text-white text-[10px] font-bold flex items-center justify-center">
            3
          </span>
        </button>
      </div>
    </header>
  );
}
