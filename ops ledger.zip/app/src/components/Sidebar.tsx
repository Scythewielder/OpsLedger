import { useAuth, type UserRole } from '@/contexts/AuthContext';
import { useLayout } from '@/contexts/LayoutContext';
import { 
  LayoutDashboard, 
  FolderKanban, 
  CheckSquare, 
  Users, 
  ClipboardList, 
  Shield, 
  Globe, 
  Settings,
  LogOut,
  ChevronRight,
  PanelLeft
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  requiredRoles: UserRole[];
}

interface SidebarProps {
  activeSection: string;
  onNavigate: (section: string) => void;
}

const navItems: NavItem[] = [
  { 
    id: 'dashboard', 
    label: 'Dashboard', 
    icon: <LayoutDashboard className="w-5 h-5" />,
    requiredRoles: ['admin', 'staff', 'client']
  },
  { 
    id: 'projects', 
    label: 'Projects', 
    icon: <FolderKanban className="w-5 h-5" />,
    requiredRoles: ['admin', 'staff', 'client']
  },
  { 
    id: 'tasks', 
    label: 'Tasks', 
    icon: <CheckSquare className="w-5 h-5" />,
    requiredRoles: ['admin', 'staff', 'client']
  },
  { 
    id: 'workload', 
    label: 'Workload', 
    icon: <Users className="w-5 h-5" />,
    requiredRoles: ['admin', 'staff']
  },
  { 
    id: 'audit', 
    label: 'Audit Logs', 
    icon: <ClipboardList className="w-5 h-5" />,
    requiredRoles: ['admin']
  },
  { 
    id: 'roles', 
    label: 'Roles & Access', 
    icon: <Shield className="w-5 h-5" />,
    requiredRoles: ['admin']
  },
  { 
    id: 'portal', 
    label: 'Client Portal', 
    icon: <Globe className="w-5 h-5" />,
    requiredRoles: ['admin', 'staff', 'client']
  },
];

export function Sidebar({ activeSection, onNavigate }: SidebarProps) {
  const { user, logout, hasPermission } = useAuth();
  const { sidebarCollapsed, toggleSidebar } = useLayout();

  const handleLogout = () => {
    logout();
    window.location.reload();
  };

  const filteredNavItems = navItems.filter(item => 
    hasPermission(item.requiredRoles)
  );

  return (
    <aside 
      className={`h-screen fixed left-0 top-0 bg-white border-r border-[var(--border)] flex flex-col z-40 transition-all duration-300 ${
        sidebarCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* User Profile Header */}
      <div className="p-4 border-b border-[var(--border)]">
        <div className={`flex items-center gap-3 ${sidebarCollapsed ? 'justify-center' : ''}`}>
          <img
            src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.name}`}
            alt={user?.name}
            className="w-10 h-10 rounded-full bg-gray-100 border border-gray-200"
          />
          {!sidebarCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm text-[var(--text-primary)] truncate">
                {user?.name}
              </p>
              <p className="text-xs text-[var(--text-muted)] capitalize">
                {user?.role}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-2 overflow-y-auto">
        <div className="space-y-1">
          {filteredNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
                activeSection === item.id
                  ? 'bg-[var(--text-primary)] text-white'
                  : 'text-[var(--text-secondary)] hover:bg-gray-100 hover:text-[var(--text-primary)]'
              } ${sidebarCollapsed ? 'justify-center' : ''}`}
              title={sidebarCollapsed ? item.label : undefined}
            >
              {item.icon}
              {!sidebarCollapsed && (
                <span className="font-medium text-sm">{item.label}</span>
              )}
            </button>
          ))}
        </div>
      </nav>

      {/* Bottom Actions */}
      <div className="p-2 border-t border-[var(--border)] space-y-1">
        <button
          onClick={() => onNavigate('settings')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-[var(--text-secondary)] hover:bg-gray-100 hover:text-[var(--text-primary)] transition-all ${
            sidebarCollapsed ? 'justify-center' : ''
          }`}
          title={sidebarCollapsed ? 'Settings' : undefined}
        >
          <Settings className="w-5 h-5" />
          {!sidebarCollapsed && <span className="font-medium text-sm">Settings</span>}
        </button>
        
        <button
          onClick={handleLogout}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-[var(--text-secondary)] hover:bg-red-50 hover:text-red-500 transition-all ${
            sidebarCollapsed ? 'justify-center' : ''
          }`}
          title={sidebarCollapsed ? 'Logout' : undefined}
        >
          <LogOut className="w-5 h-5" />
          {!sidebarCollapsed && <span className="font-medium text-sm">Logout</span>}
        </button>

        {/* Collapse Toggle */}
        <button
          onClick={toggleSidebar}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-[var(--text-muted)] hover:bg-gray-100 transition-all ${
            sidebarCollapsed ? 'justify-center' : ''
          }`}
        >
          {sidebarCollapsed ? <ChevronRight className="w-5 h-5" /> : <>
            <PanelLeft className="w-5 h-5" />
            <span className="font-medium text-sm">Collapse</span>
          </>}
        </button>
      </div>
    </aside>
  );
}
