import { createContext, useContext, useEffect, useState } from 'react';

type LayoutType = 'grid' | 'flex' | 'list';
type DensityType = 'compact' | 'comfortable' | 'spacious';

interface LayoutContextType {
  layout: LayoutType;
  density: DensityType;
  sidebarCollapsed: boolean;
  setLayout: (layout: LayoutType) => void;
  setDensity: (density: DensityType) => void;
  toggleSidebar: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
}

const LayoutContext = createContext<LayoutContextType | undefined>(undefined);

export function LayoutProvider({ children }: { children: React.ReactNode }) {
  const [layout, setLayoutState] = useState<LayoutType>('grid');
  const [density, setDensityState] = useState<DensityType>('comfortable');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  useEffect(() => {
    // Load saved preferences
    const savedLayout = localStorage.getItem('opsledger-layout') as LayoutType | null;
    const savedDensity = localStorage.getItem('opsledger-density') as DensityType | null;
    const savedSidebar = localStorage.getItem('opsledger-sidebar');
    
    if (savedLayout) setLayoutState(savedLayout);
    if (savedDensity) setDensityState(savedDensity);
    if (savedSidebar) setSidebarCollapsed(savedSidebar === 'true');
  }, []);

  const setLayout = (newLayout: LayoutType) => {
    setLayoutState(newLayout);
    localStorage.setItem('opsledger-layout', newLayout);
  };

  const setDensity = (newDensity: DensityType) => {
    setDensityState(newDensity);
    localStorage.setItem('opsledger-density', newDensity);
  };

  const toggleSidebar = () => {
    const newState = !sidebarCollapsed;
    setSidebarCollapsed(newState);
    localStorage.setItem('opsledger-sidebar', String(newState));
  };

  const setSidebarCollapsedState = (collapsed: boolean) => {
    setSidebarCollapsed(collapsed);
    localStorage.setItem('opsledger-sidebar', String(collapsed));
  };

  return (
    <LayoutContext.Provider value={{ 
      layout, 
      density, 
      sidebarCollapsed,
      setLayout, 
      setDensity,
      toggleSidebar,
      setSidebarCollapsed: setSidebarCollapsedState
    }}>
      {children}
    </LayoutContext.Provider>
  );
}

export function useLayout() {
  const context = useContext(LayoutContext);
  if (context === undefined) {
    throw new Error('useLayout must be used within a LayoutProvider');
  }
  return context;
}
