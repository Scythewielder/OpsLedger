import { createContext, useContext, useEffect, useState, useCallback } from 'react';

export type PlatformType = 'opsledger' | 'portfoliohub' | 'knowledgestack';

interface PlatformContextType {
  currentPlatform: PlatformType;
  setPlatform: (platform: PlatformType) => void;
  openPlatformInNewTab: (platform: PlatformType) => void;
}

const PlatformContext = createContext<PlatformContextType | undefined>(undefined);

export function PlatformProvider({ children }: { children: React.ReactNode }) {
  const [currentPlatform, setCurrentPlatform] = useState<PlatformType>('opsledger');

  useEffect(() => {
    const saved = localStorage.getItem('conglomerate-platform') as PlatformType | null;
    if (saved && ['opsledger', 'portfoliohub', 'knowledgestack'].includes(saved)) {
      setCurrentPlatform(saved);
    }
  }, []);

  const setPlatform = useCallback((platform: PlatformType) => {
    setCurrentPlatform(platform);
    localStorage.setItem('conglomerate-platform', platform);
    // Update document title
    const titles = {
      opsledger: 'OpsLedger - Operations Platform',
      portfoliohub: 'PortfolioHub - Creator Platform',
      knowledgestack: 'KnowledgeStack - Documentation Platform'
    };
    document.title = titles[platform];
  }, []);

  const openPlatformInNewTab = useCallback((platform: PlatformType) => {
    // Store the target platform in sessionStorage for the new tab
    sessionStorage.setItem('new-tab-platform', platform);
    // Open new tab with same URL
    window.open(window.location.href, '_blank');
  }, []);

  // Listen for keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Cmd/Ctrl + 1, 2, 3 to switch platforms
      if ((e.metaKey || e.ctrlKey) && !e.altKey && !e.shiftKey) {
        switch (e.key) {
          case '1':
            e.preventDefault();
            setPlatform('opsledger');
            break;
          case '2':
            e.preventDefault();
            setPlatform('portfoliohub');
            break;
          case '3':
            e.preventDefault();
            setPlatform('knowledgestack');
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setPlatform]);

  // Check if this is a new tab with a platform override
  useEffect(() => {
    const newTabPlatform = sessionStorage.getItem('new-tab-platform');
    if (newTabPlatform && ['opsledger', 'portfoliohub', 'knowledgestack'].includes(newTabPlatform)) {
      setCurrentPlatform(newTabPlatform as PlatformType);
      sessionStorage.removeItem('new-tab-platform');
    }
  }, []);

  return (
    <PlatformContext.Provider value={{ currentPlatform, setPlatform, openPlatformInNewTab }}>
      {children}
    </PlatformContext.Provider>
  );
}

export function usePlatform() {
  const context = useContext(PlatformContext);
  if (context === undefined) {
    throw new Error('usePlatform must be used within a PlatformProvider');
  }
  return context;
}
