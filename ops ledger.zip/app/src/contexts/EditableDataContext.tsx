import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { mockUsers, mockProjects, mockTasks, mockTeamMembers, mockAuditLogs, mockClientRequests, mockRoles, mockDashboardMetrics } from '@/data/mockData';
import type { User, Project, Task, TeamMember, AuditLog, ClientRequest, Role, DashboardMetrics } from '@/types';

interface DataState {
  users: User[];
  projects: Project[];
  tasks: Task[];
  teamMembers: TeamMember[];
  auditLogs: AuditLog[];
  clientRequests: ClientRequest[];
  roles: Role[];
  metrics: DashboardMetrics;
  currentUser: User | null;
}

interface EditableDataContextType {
  // Users
  users: User[];
  updateUser: (id: string, data: Partial<User>) => void;
  currentUser: User | null;
  updateCurrentUser: (data: Partial<User>) => void;
  
  // Projects
  projects: Project[];
  updateProject: (id: string, data: Partial<Project>) => void;
  addProject: (project: Project) => void;
  deleteProject: (id: string) => void;
  
  // Tasks
  tasks: Task[];
  updateTask: (id: string, data: Partial<Task>) => void;
  addTask: (task: Task) => void;
  deleteTask: (id: string) => void;
  
  // Team Members
  teamMembers: TeamMember[];
  updateTeamMember: (id: string, data: Partial<TeamMember>) => void;
  
  // Audit Logs
  auditLogs: AuditLog[];
  addAuditLog: (log: AuditLog) => void;
  
  // Client Requests
  clientRequests: ClientRequest[];
  updateClientRequest: (id: string, data: Partial<ClientRequest>) => void;
  addClientRequest: (request: ClientRequest) => void;
  
  // Roles
  roles: Role[];
  updateRole: (id: string, data: Partial<Role>) => void;
  
  // Metrics
  metrics: DashboardMetrics;
  updateMetrics: (data: Partial<DashboardMetrics>) => void;
  
  // Save/Reset
  saveAllChanges: () => void;
  resetToDefaults: () => void;
  hasUnsavedChanges: boolean;
}

const STORAGE_KEY = 'conglomerate-data';

const defaultData: DataState = {
  users: mockUsers,
  projects: mockProjects,
  tasks: mockTasks,
  teamMembers: mockTeamMembers,
  auditLogs: mockAuditLogs,
  clientRequests: mockClientRequests,
  roles: mockRoles,
  metrics: mockDashboardMetrics,
  currentUser: mockUsers[0]
};

const EditableDataContext = createContext<EditableDataContextType | undefined>(undefined);

export function EditableDataProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<DataState>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        return { ...defaultData, ...JSON.parse(saved) };
      } catch {
        return defaultData;
      }
    }
    return defaultData;
  });
  
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Auto-save to localStorage
  useEffect(() => {
    if (hasUnsavedChanges) {
      const timeout = setTimeout(() => {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        setHasUnsavedChanges(false);
      }, 1000);
      return () => clearTimeout(timeout);
    }
  }, [data, hasUnsavedChanges]);

  const markChanged = useCallback(() => setHasUnsavedChanges(true), []);

  // User operations
  const updateUser = useCallback((id: string, updates: Partial<User>) => {
    setData((prev: DataState) => ({
      ...prev,
      users: prev.users.map((u: User) => u.id === id ? { ...u, ...updates } : u)
    }));
    markChanged();
  }, [markChanged]);

  const updateCurrentUser = useCallback((updates: Partial<User>) => {
    setData((prev: DataState) => ({
      ...prev,
      currentUser: prev.currentUser ? { ...prev.currentUser, ...updates } : null
    }));
    markChanged();
  }, [markChanged]);

  // Project operations
  const updateProject = useCallback((id: string, updates: Partial<Project>) => {
    setData((prev: DataState) => ({
      ...prev,
      projects: prev.projects.map((p: Project) => p.id === id ? { ...p, ...updates } : p)
    }));
    markChanged();
  }, [markChanged]);

  const addProject = useCallback((project: Project) => {
    setData((prev: DataState) => ({
      ...prev,
      projects: [...prev.projects, project]
    }));
    markChanged();
  }, [markChanged]);

  const deleteProject = useCallback((id: string) => {
    setData((prev: DataState) => ({
      ...prev,
      projects: prev.projects.filter((p: Project) => p.id !== id)
    }));
    markChanged();
  }, [markChanged]);

  // Task operations
  const updateTask = useCallback((id: string, updates: Partial<Task>) => {
    setData((prev: DataState) => ({
      ...prev,
      tasks: prev.tasks.map((t: Task) => t.id === id ? { ...t, ...updates } : t)
    }));
    markChanged();
  }, [markChanged]);

  const addTask = useCallback((task: Task) => {
    setData((prev: DataState) => ({
      ...prev,
      tasks: [...prev.tasks, task]
    }));
    markChanged();
  }, [markChanged]);

  const deleteTask = useCallback((id: string) => {
    setData((prev: DataState) => ({
      ...prev,
      tasks: prev.tasks.filter((t: Task) => t.id !== id)
    }));
    markChanged();
  }, [markChanged]);

  // Team Member operations
  const updateTeamMember = useCallback((id: string, updates: Partial<TeamMember>) => {
    setData((prev: DataState) => ({
      ...prev,
      teamMembers: prev.teamMembers.map((tm: TeamMember) => tm.id === id ? { ...tm, ...updates } : tm)
    }));
    markChanged();
  }, [markChanged]);

  // Audit Log operations
  const addAuditLog = useCallback((log: AuditLog) => {
    setData((prev: DataState) => ({
      ...prev,
      auditLogs: [log, ...prev.auditLogs]
    }));
    markChanged();
  }, [markChanged]);

  // Client Request operations
  const updateClientRequest = useCallback((id: string, updates: Partial<ClientRequest>) => {
    setData((prev: DataState) => ({
      ...prev,
      clientRequests: prev.clientRequests.map((cr: ClientRequest) => cr.id === id ? { ...cr, ...updates } : cr)
    }));
    markChanged();
  }, [markChanged]);

  const addClientRequest = useCallback((request: ClientRequest) => {
    setData((prev: DataState) => ({
      ...prev,
      clientRequests: [...prev.clientRequests, request]
    }));
    markChanged();
  }, [markChanged]);

  // Role operations
  const updateRole = useCallback((id: string, updates: Partial<Role>) => {
    setData((prev: DataState) => ({
      ...prev,
      roles: prev.roles.map((r: Role) => r.id === id ? { ...r, ...updates } : r)
    }));
    markChanged();
  }, [markChanged]);

  // Metrics operations
  const updateMetrics = useCallback((updates: Partial<DashboardMetrics>) => {
    setData((prev: DataState) => ({
      ...prev,
      metrics: { ...prev.metrics, ...updates }
    }));
    markChanged();
  }, [markChanged]);

  // Save/Reset
  const saveAllChanges = useCallback(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    setHasUnsavedChanges(false);
  }, [data]);

  const resetToDefaults = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setData(defaultData);
    setHasUnsavedChanges(false);
    window.location.reload();
  }, []);

  return (
    <EditableDataContext.Provider value={{
      users: data.users,
      updateUser,
      currentUser: data.currentUser,
      updateCurrentUser,
      projects: data.projects,
      updateProject,
      addProject,
      deleteProject,
      tasks: data.tasks,
      updateTask,
      addTask,
      deleteTask,
      teamMembers: data.teamMembers,
      updateTeamMember,
      auditLogs: data.auditLogs,
      addAuditLog,
      clientRequests: data.clientRequests,
      updateClientRequest,
      addClientRequest,
      roles: data.roles,
      updateRole,
      metrics: data.metrics,
      updateMetrics,
      saveAllChanges,
      resetToDefaults,
      hasUnsavedChanges
    }}>
      {children}
    </EditableDataContext.Provider>
  );
}

export function useEditableData() {
  const context = useContext(EditableDataContext);
  if (context === undefined) {
    throw new Error('useEditableData must be used within an EditableDataProvider');
  }
  return context;
}
