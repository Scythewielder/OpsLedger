import { useState } from 'react';
import { mockProjects } from '@/data/mockData';
import { useLayout } from '@/contexts/LayoutContext';
import { 
  Plus, 
  Search, 
  MoreVertical, 
  Calendar, 
  CheckCircle2
} from 'lucide-react';

export function ProjectsSection() {
  const [activeTab, setActiveTab] = useState<'active' | 'archived'>('active');
  const [searchQuery, setSearchQuery] = useState('');
  const { layout, density, sidebarCollapsed } = useLayout();

  // Filter projects based on tab and search
  const filteredProjects = mockProjects.filter(project => {
    const matchesTab = activeTab === 'active' 
      ? project.status === 'active' || project.status === 'on_hold'
      : project.status === 'completed' || project.status === 'cancelled';
    const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  // Get density-based spacing
  const getDensityClasses = () => {
    switch (density) {
      case 'compact':
        return 'gap-4';
      case 'spacious':
        return 'gap-8';
      default:
        return 'gap-6';
    }
  };

  // Get layout classes
  const getLayoutClasses = () => {
    switch (layout) {
      case 'flex':
        return 'flex flex-col';
      case 'list':
        return 'flex flex-col';
      case 'grid':
      default:
        return 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4';
    }
  };

  const activeCount = mockProjects.filter(p => p.status === 'active' || p.status === 'on_hold').length;
  const archivedCount = mockProjects.filter(p => p.status === 'completed' || p.status === 'cancelled').length;

  return (
    <div 
      className="p-6 space-y-6 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-[var(--text-primary)]">Projects</h2>
          <p className="text-[var(--text-muted)] mt-1">Manage and track all your projects</p>
        </div>
        <button className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          New Project
        </button>
      </div>

      {/* Tabs & Search */}
      <div className="flex flex-col md:flex-row gap-4">
        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('active')}
            className={`tab ${activeTab === 'active' ? 'tab-active' : 'tab-inactive'}`}
          >
            Active ({activeCount})
          </button>
          <button
            onClick={() => setActiveTab('archived')}
            className={`tab ${activeTab === 'archived' ? 'tab-active' : 'tab-inactive'}`}
          >
            Archived ({archivedCount})
          </button>
        </div>

        {/* Search */}
        <div className="flex-1 relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
          <input
            type="text"
            placeholder="Search projects..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-muted)]"
          />
        </div>
      </div>

      {/* Projects Grid/Flex/List */}
      <div className={`${getLayoutClasses()} ${getDensityClasses()}`}>
        {filteredProjects.map((project) => (
          <div 
            key={project.id} 
            className={`card group cursor-pointer overflow-hidden ${
              layout === 'list' ? 'flex flex-row items-center p-4' : ''
            }`}
          >
            {/* Card Image/Icon Area */}
            {layout !== 'list' && (
              <div className="h-40 bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 opacity-10">
                  <svg viewBox="0 0 200 200" className="w-full h-full">
                    <circle cx="100" cy="100" r="80" fill="none" stroke="currentColor" strokeWidth="2" className="text-[var(--accent)]" />
                    <circle cx="100" cy="100" r="60" fill="none" stroke="currentColor" strokeWidth="2" className="text-[var(--accent)]" />
                    <circle cx="100" cy="100" r="40" fill="none" stroke="currentColor" strokeWidth="2" className="text-[var(--accent)]" />
                  </svg>
                </div>
                <div className="relative z-10">
                  <div className="w-16 h-16 rounded-2xl bg-white shadow-lg flex items-center justify-center">
                    <CheckCircle2 className="w-8 h-8 text-[var(--accent)]" />
                  </div>
                </div>
              </div>
            )}

            {/* Card Content */}
            <div className={`p-5 ${layout === 'list' ? 'flex-1' : ''}`}>
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-semibold text-[var(--text-primary)] line-clamp-1">{project.name}</h3>
                <button className="text-[var(--text-muted)] hover:text-[var(--text-primary)] opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>
              
              <p className="text-sm text-[var(--text-muted)] line-clamp-2 mb-4">{project.description}</p>
              
              {/* Progress */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[var(--text-muted)]">Progress</span>
                  <span className="font-medium text-[var(--accent)]">{project.progress}%</span>
                </div>
                <div className="h-2 rounded-full bg-gray-100 overflow-hidden">
                  <div 
                    className="h-full bg-[var(--accent)] rounded-full transition-all"
                    style={{ width: `${project.progress}%` }}
                  />
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-[var(--border)]">
                <div className="flex items-center gap-4 text-xs text-[var(--text-muted)]">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    {project.completedTasks}/{project.tasksCount}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(project.dueDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                  </span>
                </div>
                <div className="flex -space-x-2">
                  {project.team.slice(0, 3).map((member, i) => (
                    <img
                      key={i}
                      src={member.avatar}
                      alt={member.name}
                      className="w-6 h-6 rounded-full border-2 border-white bg-gray-100"
                    />
                  ))}
                  {project.team.length > 3 && (
                    <div className="w-6 h-6 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-[10px] text-[var(--text-muted)]">
                      +{project.team.length - 3}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredProjects.length === 0 && (
        <div className="text-center py-16">
          <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
            <Search className="w-8 h-8 text-[var(--text-muted)]" />
          </div>
          <h3 className="font-medium text-[var(--text-primary)] mb-1">No projects found</h3>
          <p className="text-[var(--text-muted)]">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}
