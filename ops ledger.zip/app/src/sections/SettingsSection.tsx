import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { useLayout } from '@/contexts/LayoutContext';
import { User, Bell, Shield, Palette, Moon, Sun, Mail, Smartphone, Check } from 'lucide-react';

export function SettingsSection() {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { sidebarCollapsed } = useLayout();

  return (
    <div 
      className="p-6 space-y-6 max-w-4xl transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      <div>
        <h2 className="text-2xl font-semibold text-[var(--text-primary)]">Settings</h2>
        <p className="text-[var(--text-muted)] mt-1">Manage your account and preferences</p>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <User className="w-5 h-5 text-[var(--accent)]" />
          <h3 className="font-semibold text-[var(--text-primary)]">Profile</h3>
        </div>
        <div className="flex items-start gap-6">
          <img
            src={user?.avatar}
            alt={user?.name}
            className="w-20 h-20 rounded-full bg-gray-100 border-2 border-white shadow-sm"
          />
          <div className="flex-1 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="section-label block mb-2">Full Name</label>
                <input
                  type="text"
                  defaultValue={user?.name}
                  className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-muted)]"
                />
              </div>
              <div>
                <label className="section-label block mb-2">Email</label>
                <input
                  type="email"
                  defaultValue={user?.email}
                  className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-muted)]"
                />
              </div>
            </div>
            <div>
              <label className="section-label block mb-2">Department</label>
              <input
                type="text"
                defaultValue={user?.department}
                className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-muted)]"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <Palette className="w-5 h-5 text-[var(--accent)]" />
          <h3 className="font-semibold text-[var(--text-primary)]">Appearance</h3>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[var(--text-primary)] font-medium">Theme</p>
            <p className="text-sm text-[var(--text-muted)]">Choose your preferred theme</p>
          </div>
          <button
            onClick={toggleTheme}
            className="flex items-center gap-3 px-4 py-3 rounded-lg border border-[var(--border)] hover:border-[var(--accent)] transition-colors"
          >
            {theme === 'dark' ? (
              <>
                <Moon className="w-5 h-5 text-[var(--accent)]" />
                <span className="text-[var(--text-primary)]">Dark Mode</span>
              </>
            ) : (
              <>
                <Sun className="w-5 h-5 text-[var(--accent)]" />
                <span className="text-[var(--text-primary)]">Light Mode</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <Bell className="w-5 h-5 text-[var(--accent)]" />
          <h3 className="font-semibold text-[var(--text-primary)]">Notifications</h3>
        </div>
        <div className="space-y-4">
          {[
            { label: 'Task assignments', description: 'Get notified when you are assigned a task' },
            { label: 'Task due dates', description: 'Reminders for upcoming task deadlines' },
            { label: 'Project updates', description: 'Notifications about project status changes' },
            { label: 'Mentions and comments', description: 'When someone mentions you in a comment' },
          ].map((item, index) => (
            <div key={index} className="flex items-center justify-between py-3 border-b border-[var(--border)] last:border-0">
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 rounded bg-[var(--accent)] flex items-center justify-center">
                  <Check className="w-3 h-3 text-white" />
                </div>
                <div>
                  <p className="text-[var(--text-primary)] font-medium">{item.label}</p>
                  <p className="text-sm text-[var(--text-muted)]">{item.description}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="p-2 rounded-lg bg-blue-50 text-blue-600">
                  <Mail className="w-4 h-4" />
                </button>
                <button className="p-2 rounded-lg bg-gray-100 text-[var(--text-muted)]">
                  <Smartphone className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="w-5 h-5 text-[var(--accent)]" />
          <h3 className="font-semibold text-[var(--text-primary)]">Security</h3>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between py-3 border-b border-[var(--border)]">
            <div>
              <p className="text-[var(--text-primary)] font-medium">Change Password</p>
              <p className="text-sm text-[var(--text-muted)]">Update your account password</p>
            </div>
            <button className="btn-secondary">Change</button>
          </div>
          <div className="flex items-center justify-between py-3 border-b border-[var(--border)]">
            <div>
              <p className="text-[var(--text-primary)] font-medium">Two-Factor Authentication</p>
              <p className="text-sm text-[var(--text-muted)]">Add an extra layer of security</p>
            </div>
            <button className="btn-secondary">Enable</button>
          </div>
          <div className="flex items-center justify-between py-3">
            <div>
              <p className="text-[var(--text-primary)] font-medium">Active Sessions</p>
              <p className="text-sm text-[var(--text-muted)]">Manage your active login sessions</p>
            </div>
            <button className="btn-secondary">View</button>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button className="btn-primary">Save Changes</button>
      </div>
    </div>
  );
}
