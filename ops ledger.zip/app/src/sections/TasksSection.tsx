import { useState } from 'react';
import { mockTasks } from '@/data/mockData';
import { useLayout } from '@/contexts/LayoutContext';
import { 
  Plus, 
  Search, 
  MoreVertical,
  Calendar,
  MessageSquare,
  CheckSquare,
  Flag,
  AlertCircle,
  X
} from 'lucide-react';

export function TasksSection() {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTask, setSelectedTask] = useState<typeof mockTasks[0] | null>(null);
  const { density, sidebarCollapsed } = useLayout();

  const filteredTasks = mockTasks.filter(task => {
    const matchesStatus = filterStatus === 'all' || task.status === filterStatus;
    const matchesPriority = filterPriority === 'all' || task.priority === filterPriority;
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesPriority && matchesSearch;
  });

  const statusColors = {
    todo: 'bg-gray-100 text-gray-600',
    in_progress: 'bg-blue-100 text-blue-600',
    review: 'bg-purple-100 text-purple-600',
    done: 'bg-green-100 text-green-600'
  };

  const priorityColors = {
    low: 'bg-gray-100 text-gray-600',
    medium: 'bg-blue-100 text-blue-600',
    high: 'bg-orange-100 text-orange-600',
    urgent: 'bg-red-100 text-red-600'
  };

  const priorityIcons = {
    low: <Flag className="w-3 h-3" />,
    medium: <Flag className="w-3 h-3" />,
    high: <Flag className="w-3 h-3" />,
    urgent: <AlertCircle className="w-3 h-3" />
  };

  // Get density-based spacing
  const getDensityClasses = () => {
    switch (density) {
      case 'compact':
        return 'gap-3';
      case 'spacious':
        return 'gap-6';
      default:
        return 'gap-4';
    }
  };

  return (
    <div 
      className="p-6 space-y-6 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-[var(--text-primary)]">Tasks</h2>
          <p className="text-[var(--text-muted)] mt-1">Track and manage team tasks</p>
        </div>
        <button className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          New Task
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
          <input
            type="text"
            placeholder="Search tasks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-muted)]"
          />
        </div>
        <div className="flex gap-2">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none"
          >
            <option value="all">All Status</option>
            <option value="todo">To Do</option>
            <option value="in_progress">In Progress</option>
            <option value="review">Review</option>
            <option value="done">Done</option>
          </select>
          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
            className="px-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none"
          >
            <option value="all">All Priorities</option>
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      {/* Tasks Board */}
      <div className={`grid grid-cols-1 lg:grid-cols-4 gap-6 ${getDensityClasses()}`}>
        {/* Task Columns */}
        {['todo', 'in_progress', 'review', 'done'].map((status) => {
          const statusTasks = filteredTasks.filter(t => t.status === status);
          const statusLabels = {
            todo: 'To Do',
            in_progress: 'In Progress',
            review: 'Review',
            done: 'Done'
          };
          
          return (
            <div key={status} className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-[var(--text-primary)] flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${
                    status === 'todo' ? 'bg-gray-400' :
                    status === 'in_progress' ? 'bg-blue-500' :
                    status === 'review' ? 'bg-purple-500' :
                    'bg-green-500'
                  }`} />
                  {statusLabels[status as keyof typeof statusLabels]}
                </h3>
                <span className="text-sm text-[var(--text-muted)]">{statusTasks.length}</span>
              </div>
              
              <div className="space-y-3">
                {statusTasks.map((task) => (
                  <div 
                    key={task.id} 
                    onClick={() => setSelectedTask(task)}
                    className="card p-4 hover:border-[var(--accent)] transition-colors cursor-pointer group"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-medium flex items-center gap-1 ${priorityColors[task.priority]}`}>
                        {priorityIcons[task.priority]}
                        {task.priority}
                      </span>
                      <button className="text-[var(--text-muted)] hover:text-[var(--text-primary)] opacity-0 group-hover:opacity-100 transition-opacity">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                    
                    <h4 className="font-medium text-[var(--text-primary)] mb-2">{task.title}</h4>
                    <p className="text-sm text-[var(--text-muted)] line-clamp-2 mb-3">{task.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3 text-xs text-[var(--text-muted)]">
                        <span className="flex items-center gap-1">
                          <MessageSquare className="w-3 h-3" />
                          {task.comments.length}
                        </span>
                        <span className="flex items-center gap-1">
                          <CheckSquare className="w-3 h-3" />
                          {task.checklist.filter(c => c.completed).length}/{task.checklist.length}
                        </span>
                      </div>
                      <img
                        src={task.assignee.avatar}
                        alt={task.assignee.name}
                        className="w-6 h-6 rounded-full"
                      />
                    </div>
                    
                    <div className="mt-3 pt-3 border-t border-[var(--border)] flex items-center gap-2">
                      <span className="text-xs text-[var(--text-muted)]">{task.project.name}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="card w-full max-w-2xl max-h-[90vh] overflow-auto bg-white">
            <div className="p-6 border-b border-[var(--border)] flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className={`px-2 py-1 rounded-full text-[10px] uppercase font-medium ${statusColors[selectedTask.status]}`}>
                    {selectedTask.status.replace('_', ' ')}
                  </span>
                  <span className={`px-2 py-1 rounded-full text-[10px] uppercase font-medium flex items-center gap-1 ${priorityColors[selectedTask.priority]}`}>
                    {priorityIcons[selectedTask.priority]}
                    {selectedTask.priority}
                  </span>
                </div>
                <h3 className="text-xl font-semibold text-[var(--text-primary)]">{selectedTask.title}</h3>
              </div>
              <button 
                onClick={() => setSelectedTask(null)}
                className="text-[var(--text-muted)] hover:text-[var(--text-primary)]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <h4 className="section-label mb-2">Description</h4>
                <p className="text-[var(--text-secondary)]">{selectedTask.description}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="section-label mb-2">Assignee</h4>
                  <div className="flex items-center gap-2">
                    <img src={selectedTask.assignee.avatar} alt={selectedTask.assignee.name} className="w-8 h-8 rounded-full" />
                    <span className="text-[var(--text-primary)]">{selectedTask.assignee.name}</span>
                  </div>
                </div>
                <div>
                  <h4 className="section-label mb-2">Due Date</h4>
                  <span className="text-[var(--text-secondary)] flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {new Date(selectedTask.dueDate).toLocaleDateString()}
                  </span>
                </div>
              </div>
              
              <div>
                <h4 className="section-label mb-3">Checklist</h4>
                <div className="space-y-2">
                  {selectedTask.checklist.map((item) => (
                    <div key={item.id} className="flex items-center gap-3">
                      <div className={`w-5 h-5 rounded border flex items-center justify-center ${
                        item.completed 
                          ? 'bg-green-500 border-green-500' 
                          : 'border-gray-300'
                      }`}>
                        {item.completed && <CheckSquare className="w-3 h-3 text-white" />}
                      </div>
                      <span className={`text-sm ${item.completed ? 'text-[var(--text-muted)] line-through' : 'text-[var(--text-primary)]'}`}>
                        {item.text}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              
              {selectedTask.comments.length > 0 && (
                <div>
                  <h4 className="section-label mb-3">Comments</h4>
                  <div className="space-y-3">
                    {selectedTask.comments.map((comment) => (
                      <div key={comment.id} className="flex gap-3">
                        <img src={comment.author.avatar} alt={comment.author.name} className="w-8 h-8 rounded-full" />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-[var(--text-primary)]">{comment.author.name}</span>
                            <span className="text-xs text-[var(--text-muted)]">{new Date(comment.createdAt).toLocaleDateString()}</span>
                          </div>
                          <p className="text-sm text-[var(--text-secondary)] mt-1">{comment.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
