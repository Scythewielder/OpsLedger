import { mockTeamMembers } from '@/data/mockData';
import { useLayout } from '@/contexts/LayoutContext';
import { 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  TrendingUp
} from 'lucide-react';

export function WorkloadSection() {
  const { sidebarCollapsed } = useLayout();

  const getAvailabilityIcon = (availability: string) => {
    switch (availability) {
      case 'available':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'busy':
        return <Clock className="w-4 h-4 text-orange-500" />;
      case 'overloaded':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      default:
        return <span className="w-4 h-4 block" />;
    }
  };

  const getAvailabilityLabel = (availability: string) => {
    switch (availability) {
      case 'available':
        return 'Available';
      case 'busy':
        return 'Busy';
      case 'overloaded':
        return 'Overloaded';
      default:
        return 'Away';
    }
  };

  const getWorkloadColor = (workload: number) => {
    if (workload < 50) return 'bg-green-500';
    if (workload < 80) return 'bg-orange-500';
    return 'bg-red-500';
  };

  return (
    <div 
      className="p-6 space-y-6 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Header */}
      <div>
        <h2 className="text-2xl font-semibold text-[var(--text-primary)]">Team Workload</h2>
        <p className="text-[var(--text-muted)] mt-1">Monitor team capacity and balance workloads</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[var(--text-primary)]">2</p>
              <p className="text-sm text-[var(--text-muted)]">Available</p>
            </div>
          </div>
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
              <Clock className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[var(--text-primary)]">2</p>
              <p className="text-sm text-[var(--text-muted)]">Busy</p>
            </div>
          </div>
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[var(--text-primary)]">0</p>
              <p className="text-sm text-[var(--text-muted)]">Overloaded</p>
            </div>
          </div>
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[var(--text-primary)]">72%</p>
              <p className="text-sm text-[var(--text-muted)]">Avg Workload</p>
            </div>
          </div>
        </div>
      </div>

      {/* Team Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {mockTeamMembers.map((member) => (
          <div key={member.id} className="card p-5">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <img
                  src={member.user.avatar}
                  alt={member.user.name}
                  className="w-14 h-14 rounded-full bg-gray-100 border-2 border-white shadow-sm"
                />
                <div>
                  <h3 className="font-medium text-[var(--text-primary)]">{member.user.name}</h3>
                  <p className="text-sm text-[var(--text-muted)]">{member.user.department}</p>
                  <div className="flex items-center gap-2 mt-1">
                    {getAvailabilityIcon(member.availability)}
                    <span className={`text-xs ${
                      member.availability === 'available' ? 'text-green-600' :
                      member.availability === 'busy' ? 'text-orange-600' :
                      member.availability === 'overloaded' ? 'text-red-600' :
                      'text-[var(--text-muted)]'
                    }`}>
                      {getAvailabilityLabel(member.availability)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Workload Bar */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[var(--text-muted)]">Workload</span>
                <span className={`text-sm font-medium ${
                  member.workload < 50 ? 'text-green-600' :
                  member.workload < 80 ? 'text-orange-600' :
                  'text-red-600'
                }`}>{member.workload}%</span>
              </div>
              <div className="h-3 rounded-full bg-gray-100 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all ${getWorkloadColor(member.workload)}`}
                  style={{ width: `${member.workload}%` }}
                />
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[var(--border)]">
              <div>
                <p className="text-2xl font-bold text-[var(--text-primary)]">{member.activeTasks}</p>
                <p className="text-xs text-[var(--text-muted)]">Active Tasks</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">{member.completedTasks}</p>
                <p className="text-xs text-[var(--text-muted)]">Completed</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Workload Distribution Chart */}
      <div className="card p-6">
        <h3 className="font-semibold text-[var(--text-primary)] mb-6">Workload Distribution</h3>
        <div className="space-y-4">
          {mockTeamMembers.map((member) => (
            <div key={member.id} className="flex items-center gap-4">
              <img
                src={member.user.avatar}
                alt={member.user.name}
                className="w-8 h-8 rounded-full"
              />
              <span className="w-32 text-sm text-[var(--text-primary)] truncate">{member.user.name}</span>
              <div className="flex-1 h-8 rounded-lg bg-gray-100 overflow-hidden">
                <div 
                  className={`h-full ${getWorkloadColor(member.workload)} flex items-center justify-end px-3`}
                  style={{ width: `${member.workload}%` }}
                >
                  <span className="text-xs font-medium text-white">{member.workload}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
