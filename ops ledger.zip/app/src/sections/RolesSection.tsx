import { useState } from 'react';
import { mockRoles, mockPermissions } from '@/data/mockData';
import { useLayout } from '@/contexts/LayoutContext';
import { 
  Plus, 
  Search, 
  Shield, 
  Users, 
  Check,
  X,
  Edit2,
  ChevronDown,
  ChevronRight
} from 'lucide-react';

export function RolesSection() {
  const [selectedRole, setSelectedRole] = useState<typeof mockRoles[0] | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedRoles, setExpandedRoles] = useState<string[]>([]);
  const { sidebarCollapsed } = useLayout();

  const filteredRoles = mockRoles.filter(role =>
    role.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    role.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleRoleExpand = (roleId: string) => {
    setExpandedRoles(prev =>
      prev.includes(roleId)
        ? prev.filter(id => id !== roleId)
        : [...prev, roleId]
    );
  };

  const permissionCategories = ['projects', 'tasks', 'users', 'audit', 'settings'];

  return (
    <div 
      className="p-6 space-y-6 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-[var(--text-primary)]">Roles & Access</h2>
          <p className="text-[var(--text-muted)] mt-1">Manage user roles and permissions</p>
        </div>
        <button className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Create Role
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
        <input
          type="text"
          placeholder="Search roles..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-muted)]"
        />
      </div>

      {/* Roles Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredRoles.map((role) => (
          <div key={role.id} className="card overflow-hidden">
            {/* Role Header */}
            <div 
              className="p-5 flex items-start justify-between cursor-pointer hover:bg-gray-50 transition-colors"
              onClick={() => toggleRoleExpand(role.id)}
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-[var(--text-primary)]">{role.name}</h3>
                  <p className="text-sm text-[var(--text-muted)] mt-1">{role.description}</p>
                  <div className="flex items-center gap-4 mt-2">
                    <span className="flex items-center gap-1 text-xs text-[var(--text-secondary)]">
                      <Users className="w-3 h-3" />
                      {role.userCount} users
                    </span>
                    <span className="text-xs text-[var(--text-secondary)]">
                      {role.permissions.length} permissions
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  className="p-2 rounded-lg text-[var(--text-muted)] hover:text-blue-600 hover:bg-blue-50 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedRole(role);
                  }}
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                {expandedRoles.includes(role.id) ? (
                  <ChevronDown className="w-5 h-5 text-[var(--text-muted)]" />
                ) : (
                  <ChevronRight className="w-5 h-5 text-[var(--text-muted)]" />
                )}
              </div>
            </div>

            {/* Expanded Permissions */}
            {expandedRoles.includes(role.id) && (
              <div className="px-5 pb-5 border-t border-[var(--border)]">
                <div className="pt-4 space-y-4">
                  {permissionCategories.map(category => {
                    const categoryPermissions = role.permissions.filter(p => p.category === category);
                    if (categoryPermissions.length === 0) return null;
                    
                    return (
                      <div key={category}>
                        <h4 className="section-label mb-2 capitalize">{category}</h4>
                        <div className="flex flex-wrap gap-2">
                          {categoryPermissions.map(permission => (
                            <span 
                              key={permission.id}
                              className="px-3 py-1 rounded-full text-xs bg-blue-50 text-blue-600"
                            >
                              {permission.name}
                            </span>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* All Permissions Reference */}
      <div className="card p-6">
        <h3 className="font-semibold text-[var(--text-primary)] mb-4">All Permissions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {permissionCategories.map(category => {
            const categoryPermissions = mockPermissions.filter(p => p.category === category);
            return (
              <div key={category} className="space-y-2">
                <h4 className="section-label capitalize">{category}</h4>
                <div className="space-y-1">
                  {categoryPermissions.map(permission => (
                    <div 
                      key={permission.id}
                      className="flex items-center gap-2 p-2 rounded-lg bg-gray-50"
                    >
                      <Check className="w-3 h-3 text-green-600" />
                      <span className="text-sm text-[var(--text-secondary)]">{permission.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Edit Role Modal */}
      {selectedRole && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="card w-full max-w-lg bg-white">
            <div className="p-6 border-b border-[var(--border)] flex items-center justify-between">
              <h3 className="text-lg font-semibold text-[var(--text-primary)]">
                Edit Role: {selectedRole.name}
              </h3>
              <button 
                onClick={() => setSelectedRole(null)}
                className="text-[var(--text-muted)] hover:text-[var(--text-primary)]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="section-label block mb-2">Role Name</label>
                <input
                  type="text"
                  defaultValue={selectedRole.name}
                  className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none"
                />
              </div>
              <div>
                <label className="section-label block mb-2">Description</label>
                <textarea
                  defaultValue={selectedRole.description}
                  rows={3}
                  className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none resize-none"
                />
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <button 
                  onClick={() => setSelectedRole(null)}
                  className="btn-secondary"
                >
                  Cancel
                </button>
                <button className="btn-primary">
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
