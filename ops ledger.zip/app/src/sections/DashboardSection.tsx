import { useAuth } from '@/contexts/AuthContext';
import { useLayout } from '@/contexts/LayoutContext';
import { 
  FolderKanban, 
  CheckSquare, 
  Users, 
  Clock,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  ArrowUpRight
} from 'lucide-react';
import { mockDashboardMetrics, mockProjects, mockTasks } from '@/data/mockData';

export function DashboardSection() {
  const { user } = useAuth();
  const { sidebarCollapsed } = useLayout();
  const metrics = mockDashboardMetrics;

  const statCards = [
    {
      label: 'Total Projects',
      value: metrics.totalProjects,
      change: '+12%',
      icon: <FolderKanban className="w-5 h-5" />,
      color: 'bg-blue-500'
    },
    {
      label: 'Active Tasks',
      value: metrics.inProgressTasks,
      change: '+5%',
      icon: <CheckSquare className="w-5 h-5" />,
      color: 'bg-green-500'
    },
    {
      label: 'Team Members',
      value: metrics.teamMembers,
      change: '0%',
      icon: <Users className="w-5 h-5" />,
      color: 'bg-purple-500'
    },
    {
      label: 'Avg Completion',
      value: `${metrics.averageCompletionTime}d`,
      change: '-8%',
      icon: <Clock className="w-5 h-5" />,
      color: 'bg-orange-500'
    }
  ];

  const recentProjects = mockProjects.slice(0, 3);
  const recentTasks = mockTasks.slice(0, 5);

  return (
    <div 
      className="p-6 space-y-6 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Welcome */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-[var(--text-primary)]">
            Welcome back, {user?.name.split(' ')[0]}
          </h2>
          <p className="text-[var(--text-muted)] mt-1">
            Here's what's happening with your operations today.
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-[var(--text-muted)]">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, index) => (
          <div key={index} className="card p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[var(--text-muted)] text-sm">{stat.label}</p>
                <p className="text-3xl font-bold text-[var(--text-primary)] mt-2">{stat.value}</p>
                <div className="flex items-center gap-1 mt-2">
                  <span className={`text-xs font-medium ${stat.change.startsWith('+') ? 'text-green-500' : stat.change.startsWith('-') ? 'text-green-500' : 'text-[var(--text-muted)]'}`}>
                    {stat.change}
                  </span>
                  <span className="text-xs text-[var(--text-muted)]">vs last month</span>
                </div>
              </div>
              <div className={`w-10 h-10 rounded-lg ${stat.color} bg-opacity-10 flex items-center justify-center ${stat.color.replace('bg-', 'text-')}`}>
                {stat.icon}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Projects */}
        <div className="lg:col-span-2 card">
          <div className="p-5 border-b border-[var(--border)] flex items-center justify-between">
            <h3 className="font-semibold text-[var(--text-primary)]">Recent Projects</h3>
            <button className="text-sm text-[var(--accent)] hover:underline flex items-center gap-1">
              View All
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
          <div className="p-5">
            <div className="space-y-4">
              {recentProjects.map((project) => (
                <div key={project.id} className="flex items-center gap-4 p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-[var(--text-primary)]">{project.name}</h4>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-medium ${
                        project.status === 'active' ? 'badge-success' :
                        project.status === 'completed' ? 'bg-blue-100 text-blue-600' :
                        'badge-warning'
                      }`}>
                        {project.status}
                      </span>
                    </div>
                    <p className="text-sm text-[var(--text-muted)] mt-1 line-clamp-1">{project.description}</p>
                    <div className="flex items-center gap-4 mt-3">
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 rounded-full bg-gray-200 overflow-hidden">
                          <div 
                            className="h-full bg-[var(--accent)] rounded-full"
                            style={{ width: `${project.progress}%` }}
                          />
                        </div>
                        <span className="text-xs text-[var(--text-muted)]">{project.progress}%</span>
                      </div>
                      <span className="text-xs text-[var(--text-muted)]">
                        Due {new Date(project.dueDate).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <div className="flex -space-x-2">
                    {project.team.slice(0, 3).map((member, i) => (
                      <img
                        key={i}
                        src={member.avatar}
                        alt={member.name}
                        className="w-8 h-8 rounded-full border-2 border-white bg-gray-100"
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Task Summary */}
        <div className="card">
          <div className="p-5 border-b border-[var(--border)]">
            <h3 className="font-semibold text-[var(--text-primary)]">Task Summary</h3>
          </div>
          <div className="p-5">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-green-50">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                  </div>
                  <span className="text-sm text-[var(--text-primary)]">Completed</span>
                </div>
                <span className="font-semibold text-green-600">{metrics.completedTasks}</span>
              </div>
              
              <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-blue-600" />
                  </div>
                  <span className="text-sm text-[var(--text-primary)]">In Progress</span>
                </div>
                <span className="font-semibold text-blue-600">{metrics.inProgressTasks}</span>
              </div>
              
              <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
                    <Clock className="w-4 h-4 text-purple-600" />
                  </div>
                  <span className="text-sm text-[var(--text-primary)]">Pending</span>
                </div>
                <span className="font-semibold text-purple-600">{metrics.pendingTasks}</span>
              </div>
              
              <div className="flex items-center justify-between p-3 rounded-lg bg-red-50">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center">
                    <AlertCircle className="w-4 h-4 text-red-600" />
                  </div>
                  <span className="text-sm text-[var(--text-primary)]">Overdue</span>
                </div>
                <span className="font-semibold text-red-600">{metrics.overdueTasks}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Tasks */}
      <div className="card">
        <div className="p-5 border-b border-[var(--border)] flex items-center justify-between">
          <h3 className="font-semibold text-[var(--text-primary)]">Recent Tasks</h3>
          <button className="text-sm text-[var(--accent)] hover:underline flex items-center gap-1">
            View All
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
        <div className="p-5">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-xs text-[var(--text-muted)] uppercase tracking-wider">
                  <th className="pb-3 font-medium">Task</th>
                  <th className="pb-3 font-medium">Project</th>
                  <th className="pb-3 font-medium">Assignee</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium">Priority</th>
                  <th className="pb-3 font-medium">Due Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border)]">
                {recentTasks.map((task) => (
                  <tr key={task.id} className="group hover:bg-gray-50 transition-colors cursor-pointer">
                    <td className="py-4">
                      <span className="font-medium text-[var(--text-primary)]">{task.title}</span>
                    </td>
                    <td className="py-4 text-sm text-[var(--text-secondary)]">{task.project.name}</td>
                    <td className="py-4">
                      <div className="flex items-center gap-2">
                        <img
                          src={task.assignee.avatar}
                          alt={task.assignee.name}
                          className="w-6 h-6 rounded-full"
                        />
                        <span className="text-sm text-[var(--text-secondary)]">{task.assignee.name}</span>
                      </div>
                    </td>
                    <td className="py-4">
                      <span className={`px-2 py-1 rounded-full text-[10px] uppercase font-medium ${
                        task.status === 'done' ? 'bg-green-100 text-green-600' :
                        task.status === 'in_progress' ? 'bg-blue-100 text-blue-600' :
                        task.status === 'review' ? 'bg-purple-100 text-purple-600' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {task.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-4">
                      <span className={`px-2 py-1 rounded-full text-[10px] uppercase font-medium ${
                        task.priority === 'urgent' ? 'bg-red-100 text-red-600' :
                        task.priority === 'high' ? 'bg-orange-100 text-orange-600' :
                        task.priority === 'medium' ? 'bg-blue-100 text-blue-600' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {task.priority}
                      </span>
                    </td>
                    <td className="py-4 text-sm text-[var(--text-secondary)]">
                      {new Date(task.dueDate).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
