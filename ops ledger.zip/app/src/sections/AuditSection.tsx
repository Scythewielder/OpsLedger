import { useState } from 'react';
import { mockAuditLogs } from '@/data/mockData';
import { useLayout } from '@/contexts/LayoutContext';
import { 
  Search, 
  Download,
  Calendar,
  Plus,
  Edit,
  Trash2,
  Eye,
  CheckCircle2
} from 'lucide-react';

export function AuditSection() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAction, setFilterAction] = useState<string>('all');
  const [filterEntity, setFilterEntity] = useState<string>('all');
  const { sidebarCollapsed } = useLayout();

  const filteredLogs = mockAuditLogs.filter(log => {
    const matchesSearch = log.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         log.entityName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAction = filterAction === 'all' || log.action === filterAction;
    const matchesEntity = filterEntity === 'all' || log.entityType === filterEntity;
    return matchesSearch && matchesAction && matchesEntity;
  });

  const actionIcons = {
    created: <Plus className="w-4 h-4" />,
    updated: <Edit className="w-4 h-4" />,
    deleted: <Trash2 className="w-4 h-4" />,
    viewed: <Eye className="w-4 h-4" />,
    assigned: <Calendar className="w-4 h-4" />,
    status_changed: <CheckCircle2 className="w-4 h-4" />
  };

  const actionColors = {
    created: 'bg-green-100 text-green-600',
    updated: 'bg-blue-100 text-blue-600',
    deleted: 'bg-red-100 text-red-600',
    viewed: 'bg-gray-100 text-gray-600',
    assigned: 'bg-purple-100 text-purple-600',
    status_changed: 'bg-orange-100 text-orange-600'
  };

  return (
    <div 
      className="p-6 space-y-6 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-[var(--text-primary)]">Audit Logs</h2>
          <p className="text-[var(--text-muted)] mt-1">Track all system activities and changes</p>
        </div>
        <button className="btn-secondary flex items-center gap-2">
          <Download className="w-4 h-4" />
          Export Logs
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
          <input
            type="text"
            placeholder="Search by user or entity..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent-muted)]"
          />
        </div>
        <div className="flex gap-2">
          <select
            value={filterAction}
            onChange={(e) => setFilterAction(e.target.value)}
            className="px-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none"
          >
            <option value="all">All Actions</option>
            <option value="created">Created</option>
            <option value="updated">Updated</option>
            <option value="deleted">Deleted</option>
            <option value="viewed">Viewed</option>
            <option value="assigned">Assigned</option>
            <option value="status_changed">Status Changed</option>
          </select>
          <select
            value={filterEntity}
            onChange={(e) => setFilterEntity(e.target.value)}
            className="px-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none"
          >
            <option value="all">All Entities</option>
            <option value="project">Projects</option>
            <option value="task">Tasks</option>
            <option value="user">Users</option>
            <option value="role">Roles</option>
            <option value="setting">Settings</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="card overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr className="text-left text-xs text-[var(--text-muted)] uppercase tracking-wider">
              <th className="p-4 font-medium">Timestamp</th>
              <th className="p-4 font-medium">User</th>
              <th className="p-4 font-medium">Action</th>
              <th className="p-4 font-medium">Entity</th>
              <th className="p-4 font-medium">Details</th>
              <th className="p-4 font-medium">IP Address</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--border)]">
            {filteredLogs.map((log) => (
              <tr key={log.id} className="group hover:bg-gray-50 transition-colors">
                <td className="p-4">
                  <span className="text-sm text-[var(--text-secondary)] flex items-center gap-2">
                    <Calendar className="w-3 h-3" />
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex items-center gap-2">
                    <img
                      src={log.user.avatar}
                      alt={log.user.name}
                      className="w-7 h-7 rounded-full"
                    />
                    <span className="text-sm text-[var(--text-primary)]">{log.user.name}</span>
                  </div>
                </td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded-full text-[10px] uppercase font-medium flex items-center gap-1 w-fit ${actionColors[log.action]}`}>
                    {actionIcons[log.action]}
                    {log.action.replace('_', ' ')}
                  </span>
                </td>
                <td className="p-4">
                  <div>
                    <span className="text-sm text-[var(--text-primary)]">{log.entityName}</span>
                    <span className="text-xs text-[var(--text-muted)] ml-2">({log.entityType})</span>
                  </div>
                </td>
                <td className="p-4">
                  <span className="text-sm text-[var(--text-secondary)]">{log.details}</span>
                </td>
                <td className="p-4">
                  <span className="text-sm text-[var(--text-muted)] font-mono">{log.ipAddress}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
            <Plus className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <p className="text-xl font-bold text-[var(--text-primary)]">
              {mockAuditLogs.filter(l => l.action === 'created').length}
            </p>
            <p className="text-xs text-[var(--text-muted)]">Created</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
            <Edit className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <p className="text-xl font-bold text-[var(--text-primary)]">
              {mockAuditLogs.filter(l => l.action === 'updated').length}
            </p>
            <p className="text-xs text-[var(--text-muted)]">Updated</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5 text-orange-600" />
          </div>
          <div>
            <p className="text-xl font-bold text-[var(--text-primary)]">
              {mockAuditLogs.filter(l => l.action === 'status_changed').length}
            </p>
            <p className="text-xs text-[var(--text-muted)]">Status Changes</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center">
            <Eye className="w-5 h-5 text-gray-600" />
          </div>
          <div>
            <p className="text-xl font-bold text-[var(--text-primary)]">
              {mockAuditLogs.filter(l => l.action === 'viewed').length}
            </p>
            <p className="text-xs text-[var(--text-muted)]">Views</p>
          </div>
        </div>
      </div>
    </div>
  );
}
