import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLayout } from '@/contexts/LayoutContext';
import { mockClientRequests, mockProjects } from '@/data/mockData';
import { 
  Plus, 
  X,
  Send
} from 'lucide-react';

export function ClientPortalSection() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'projects' | 'requests'>('projects');
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const { sidebarCollapsed } = useLayout();

  const isClient = user?.role === 'client';
  
  // Filter projects for client view
  const clientProjects = mockProjects.filter(p => 
    isClient ? p.client?.id === user?.id : true
  );

  const filteredRequests = mockClientRequests.filter(r =>
    filterStatus === 'all' || r.status === filterStatus
  );

  const statusColors = {
    pending: 'bg-orange-100 text-orange-600',
    in_progress: 'bg-blue-100 text-blue-600',
    completed: 'bg-green-100 text-green-600',
    rejected: 'bg-red-100 text-red-600'
  };

  return (
    <div 
      className="p-6 space-y-6 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-[var(--text-primary)]">
            {isClient ? 'My Portal' : 'Client Portal'}
          </h2>
          <p className="text-[var(--text-muted)] mt-1">
            {isClient ? 'Track your projects and submit requests' : 'Manage client access and requests'}
          </p>
        </div>
        {isClient && (
          <button 
            onClick={() => setShowRequestModal(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Request
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[var(--border)]">
        <button
          onClick={() => setActiveTab('projects')}
          className={`px-6 py-3 text-sm font-medium transition-colors relative ${
            activeTab === 'projects'
              ? 'text-[var(--accent)]'
              : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
          }`}
        >
          Projects
          {activeTab === 'projects' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--accent)]" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('requests')}
          className={`px-6 py-3 text-sm font-medium transition-colors relative ${
            activeTab === 'requests'
              ? 'text-[var(--accent)]'
              : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
          }`}
        >
          Requests
          {activeTab === 'requests' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--accent)]" />
          )}
        </button>
      </div>

      {/* Projects Tab */}
      {activeTab === 'projects' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {clientProjects.map((project) => (
            <div key={project.id} className="card p-5">
              <div className="flex items-start justify-between mb-4">
                <span className={`px-2 py-1 rounded-full text-[10px] uppercase font-medium ${
                  project.status === 'active' ? 'bg-green-100 text-green-600' :
                  project.status === 'completed' ? 'bg-blue-100 text-blue-600' :
                  'bg-orange-100 text-orange-600'
                }`}>
                  {project.status}
                </span>
                <span className="text-xs text-[var(--text-muted)]">
                  Due {new Date(project.dueDate).toLocaleDateString()}
                </span>
              </div>
              
              <h3 className="font-semibold text-[var(--text-primary)] mb-2">{project.name}</h3>
              <p className="text-sm text-[var(--text-muted)] line-clamp-2 mb-4">{project.description}</p>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[var(--text-muted)]">Progress</span>
                  <span className="text-[var(--accent)] font-medium">{project.progress}%</span>
                </div>
                <div className="h-2 rounded-full bg-gray-100 overflow-hidden">
                  <div 
                    className="h-full bg-[var(--accent)] rounded-full"
                    style={{ width: `${project.progress}%` }}
                  />
                </div>
                
                <div className="flex items-center justify-between pt-3 border-t border-[var(--border)]">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[var(--text-muted)]">
                      {project.completedTasks}/{project.tasksCount} tasks completed
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[var(--text-muted)]">Project Manager:</span>
                    <img
                      src={project.owner.avatar}
                      alt={project.owner.name}
                      className="w-6 h-6 rounded-full"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Requests Tab */}
      {activeTab === 'requests' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] focus:border-[var(--accent)] focus:outline-none"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>

          <div className="space-y-3">
            {filteredRequests.map((request) => (
              <div key={request.id} className="card p-5">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="font-medium text-[var(--text-primary)]">{request.title}</h4>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-medium ${statusColors[request.status]}`}>
                        {request.status}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-medium ${
                        request.priority === 'high' ? 'bg-orange-100 text-orange-600' :
                        request.priority === 'medium' ? 'bg-blue-100 text-blue-600' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {request.priority}
                      </span>
                    </div>
                    <p className="text-sm text-[var(--text-muted)] mb-3">{request.description}</p>
                    <div className="flex items-center gap-4 text-xs text-[var(--text-muted)]">
                      <span>Submitted: {new Date(request.submittedAt).toLocaleDateString()}</span>
                      {request.assignedTo && (
                        <span className="flex items-center gap-1">
                          Assigned to:
                          <img src={request.assignedTo.avatar} alt={request.assignedTo.name} className="w-4 h-4 rounded-full" />
                          {request.assignedTo.name}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* New Request Modal */}
      {showRequestModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="card w-full max-w-lg bg-white">
            <div className="p-6 border-b border-[var(--border)] flex items-center justify-between">
              <h3 className="text-lg font-semibold text-[var(--text-primary)]">
                Submit New Request
              </h3>
              <button 
                onClick={() => setShowRequestModal(false)}
                className="text-[var(--text-muted)] hover:text-[var(--text-primary)]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="section-label block mb-2">Title</label>
                <input
                  type="text"
                  placeholder="Brief description of your request"
                  className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:border-[var(--accent)] focus:outline-none"
                />
              </div>
              <div>
                <label className="section-label block mb-2">Description</label>
                <textarea
                  placeholder="Provide more details about your request..."
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-[var(--border)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:border-[var(--accent)] focus:outline-none resize-none"
                />
              </div>
              <div>
                <label className="section-label block mb-2">Priority</label>
                <div className="flex gap-2">
                  {['low', 'medium', 'high'].map((priority) => (
                    <button
                      key={priority}
                      className="flex-1 px-4 py-3 rounded-lg border border-[var(--border)] text-[var(--text-secondary)] hover:border-[var(--accent)] hover:text-[var(--accent)] transition-colors capitalize"
                    >
                      {priority}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <button 
                  onClick={() => setShowRequestModal(false)}
                  className="btn-secondary"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => setShowRequestModal(false)}
                  className="btn-primary flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  Submit Request
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
