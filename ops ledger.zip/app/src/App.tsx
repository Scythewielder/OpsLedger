import { useState, useEffect } from 'react';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { LayoutProvider, useLayout } from '@/contexts/LayoutContext';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { PlatformProvider, usePlatform, type PlatformType } from '@/contexts/PlatformContext';
import { EditableDataProvider, useEditableData } from '@/contexts/EditableDataContext';
import { Login } from '@/components/Login';
import { Sidebar } from '@/components/Sidebar';
import { TopBar } from '@/components/TopBar';
import { DashboardSection } from '@/sections/DashboardSection';
import { ProjectsSection } from '@/sections/ProjectsSection';
import { TasksSection } from '@/sections/TasksSection';
import { WorkloadSection } from '@/sections/WorkloadSection';
import { AuditSection } from '@/sections/AuditSection';
import { RolesSection } from '@/sections/RolesSection';
import { ClientPortalSection } from '@/sections/ClientPortalSection';
import { SettingsSection } from '@/sections/SettingsSection';
import { PortfolioHub } from '@/platforms/PortfolioHub';
import { KnowledgeStack } from '@/platforms/KnowledgeStack';
import { 
  Building2, 
  Folder, 
  BookOpen, 
  Keyboard,
  X,
  Save,
  RotateCcw
} from 'lucide-react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

// Platform Switcher Component
function PlatformSwitcher() {
  const { currentPlatform, setPlatform, openPlatformInNewTab } = usePlatform();
  const [showShortcuts, setShowShortcuts] = useState(false);

  const platforms: { id: PlatformType; label: string; icon: React.ReactNode; color: string; shortcut: string }[] = [
    { 
      id: 'opsledger', 
      label: 'OpsLedger', 
      icon: <Building2 className="w-4 h-4" />, 
      color: 'bg-blue-500',
      shortcut: '1'
    },
    { 
      id: 'portfoliohub', 
      label: 'PortfolioHub', 
      icon: <Folder className="w-4 h-4" />, 
      color: 'bg-indigo-500',
      shortcut: '2'
    },
    { 
      id: 'knowledgestack', 
      label: 'KnowledgeStack', 
      icon: <BookOpen className="w-4 h-4" />, 
      color: 'bg-teal-500',
      shortcut: '3'
    }
  ];

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Show shortcuts help on Cmd/Ctrl + K
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowShortcuts(true);
      }
      
      // Hide shortcuts on Escape
      if (e.key === 'Escape') {
        setShowShortcuts(false);
      }

      // Platform switching with Cmd/Ctrl + 1/2/3
      if ((e.metaKey || e.ctrlKey) && !e.altKey && !e.shiftKey) {
        if (e.key === '1') {
          e.preventDefault();
          setPlatform('opsledger');
        } else if (e.key === '2') {
          e.preventDefault();
          setPlatform('portfoliohub');
        } else if (e.key === '3') {
          e.preventDefault();
          setPlatform('knowledgestack');
        }
      }

      // Open in new tab with Cmd/Ctrl + Shift + 1/2/3
      if ((e.metaKey || e.ctrlKey) && e.shiftKey) {
        if (e.key === '!') {
          e.preventDefault();
          openPlatformInNewTab('opsledger');
        } else if (e.key === '@') {
          e.preventDefault();
          openPlatformInNewTab('portfoliohub');
        } else if (e.key === '#') {
          e.preventDefault();
          openPlatformInNewTab('knowledgestack');
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setPlatform, openPlatformInNewTab]);

  return (
    <>
      {/* Platform Switcher Bar */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
        <div className="flex items-center gap-2 p-2 bg-white rounded-2xl shadow-xl border border-gray-200">
          {platforms.map((platform) => (
            <div key={platform.id} className="relative group">
              <button
                onClick={() => setPlatform(platform.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all ${
                  currentPlatform === platform.id
                    ? `${platform.color} text-white shadow-md`
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {platform.icon}
                <span className="font-medium text-sm">{platform.label}</span>
              </button>
              
              {/* Tooltip */}
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                Cmd/Ctrl + {platform.shortcut}
              </div>
            </div>
          ))}
          
          <div className="w-px h-8 bg-gray-200 mx-1" />
          
          <button
            onClick={() => setShowShortcuts(true)}
            className="p-2.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
            title="Keyboard Shortcuts"
          >
            <Keyboard className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Shortcuts Modal */}
      {showShortcuts && (
        <div 
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={() => setShowShortcuts(false)}
        >
          <div 
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Keyboard Shortcuts</h2>
              <button 
                onClick={() => setShowShortcuts(false)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">Platform Switching</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-700">Switch to OpsLedger</span>
                    <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-sm font-mono">Cmd/Ctrl + 1</kbd>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-700">Switch to PortfolioHub</span>
                    <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-sm font-mono">Cmd/Ctrl + 2</kbd>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-700">Switch to KnowledgeStack</span>
                    <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-sm font-mono">Cmd/Ctrl + 3</kbd>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">Multi-Tab</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-700">Open OpsLedger in new tab</span>
                    <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-sm font-mono">Cmd/Ctrl + Shift + 1</kbd>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-700">Open PortfolioHub in new tab</span>
                    <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-sm font-mono">Cmd/Ctrl + Shift + 2</kbd>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-700">Open KnowledgeStack in new tab</span>
                    <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-sm font-mono">Cmd/Ctrl + Shift + 3</kbd>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">General</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-700">Show keyboard shortcuts</span>
                    <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-sm font-mono">Cmd/Ctrl + K</kbd>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-700">Close modal / Cancel</span>
                    <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-sm font-mono">Esc</kbd>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// Data Save Indicator
function DataSaveIndicator() {
  const { hasUnsavedChanges, saveAllChanges, resetToDefaults } = useEditableData();
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  if (!hasUnsavedChanges) return null;

  return (
    <>
      <div className="fixed top-20 right-6 z-40 flex items-center gap-2">
        <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 border border-amber-200 rounded-lg shadow-lg">
          <span className="w-2 h-2 bg-amber-500 rounded-full animate-pulse" />
          <span className="text-sm text-amber-700">Unsaved changes</span>
        </div>
        <button
          onClick={saveAllChanges}
          className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg shadow-lg hover:bg-green-600 transition-colors"
        >
          <Save className="w-4 h-4" />
          Save
        </button>
        <button
          onClick={() => setShowResetConfirm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gray-500 text-white rounded-lg shadow-lg hover:bg-gray-600 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
          Reset
        </button>
      </div>

      {showResetConfirm && (
        <div 
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={() => setShowResetConfirm(false)}
        >
          <div 
            className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="text-xl font-bold text-gray-900 mb-2">Reset All Data?</h2>
            <p className="text-gray-500 mb-6">This will restore all data to default values. Your custom changes will be lost.</p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 px-4 py-2 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  resetToDefaults();
                  setShowResetConfirm(false);
                }}
                className="flex-1 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// OpsLedger Dashboard
function OpsLedgerDashboard() {
  const [activeSection, setActiveSection] = useState('dashboard');
  const { sidebarCollapsed } = useLayout();

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.dashboard-content',
        { opacity: 0, y: 10 },
        { opacity: 1, y: 0, duration: 0.3, ease: 'power2.out' }
      );
    });
    return () => ctx.revert();
  }, [activeSection]);

  const renderSection = () => {
    switch (activeSection) {
      case 'dashboard': return <DashboardSection />;
      case 'projects': return <ProjectsSection />;
      case 'tasks': return <TasksSection />;
      case 'workload': return <WorkloadSection />;
      case 'audit': return <AuditSection />;
      case 'roles': return <RolesSection />;
      case 'portal': return <ClientPortalSection />;
      case 'settings': return <SettingsSection />;
      default: return <DashboardSection />;
    }
  };

  const sectionTitles: Record<string, { title: string; subtitle?: string; showLayoutSwitcher?: boolean }> = {
    dashboard: { title: 'Dashboard', subtitle: 'Overview of your operations', showLayoutSwitcher: false },
    projects: { title: 'Projects', subtitle: 'Manage your projects', showLayoutSwitcher: true },
    tasks: { title: 'Tasks', subtitle: 'Track and manage tasks', showLayoutSwitcher: true },
    workload: { title: 'Workload', subtitle: 'Team capacity overview', showLayoutSwitcher: true },
    audit: { title: 'Audit Logs', subtitle: 'System activity tracking', showLayoutSwitcher: true },
    roles: { title: 'Roles & Access', subtitle: 'Permission management', showLayoutSwitcher: false },
    portal: { title: 'Client Portal', subtitle: 'Client access management', showLayoutSwitcher: true },
    settings: { title: 'Settings', subtitle: 'Account preferences', showLayoutSwitcher: false }
  };

  const currentTitle = sectionTitles[activeSection] || sectionTitles.dashboard;

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar activeSection={activeSection} onNavigate={setActiveSection} />
      <div 
        className="min-h-screen transition-all duration-300"
        style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
      >
        <TopBar 
          title={currentTitle.title} 
          subtitle={currentTitle.subtitle}
          showLayoutSwitcher={currentTitle.showLayoutSwitcher}
        />
        <main className="dashboard-content">
          {renderSection()}
        </main>
      </div>
    </div>
  );
}

// Main App Content
function AppContent() {
  const { isAuthenticated } = useAuth();
  const { currentPlatform } = usePlatform();
  const [showDashboard, setShowDashboard] = useState(false);

  useEffect(() => {
    if (isAuthenticated) {
      setShowDashboard(true);
    }
  }, [isAuthenticated]);

  if (!isAuthenticated || !showDashboard) {
    return <Login onLogin={() => setShowDashboard(true)} />;
  }

  return (
    <>
      <DataSaveIndicator />
      
      {currentPlatform === 'opsledger' && <OpsLedgerDashboard />}
      {currentPlatform === 'portfoliohub' && <PortfolioHub />}
      {currentPlatform === 'knowledgestack' && <KnowledgeStack />}
      
      <PlatformSwitcher />
    </>
  );
}

function App() {
  return (
    <ThemeProvider>
      <LayoutProvider>
        <EditableDataProvider>
          <PlatformProvider>
            <AuthProvider>
              <AppContent />
            </AuthProvider>
          </PlatformProvider>
        </EditableDataProvider>
      </LayoutProvider>
    </ThemeProvider>
  );
}

export default App;
