export interface PortfolioCreator {
  id: string;
  name: string;
  username: string;
  avatar: string;
  bio: string;
  location: string;
  website?: string;
  skills: string[];
  followers: number;
  following: number;
  projectsCount: number;
  isVerified: boolean;
}

export interface PortfolioProject {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  creatorId: string;
  tags: string[];
  likes: number;
  views: number;
  createdAt: string;
  link?: string;
}

export interface PortfolioLink {
  id: string;
  title: string;
  url: string;
  icon: string;
}

export const mockCreators: PortfolioCreator[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    username: 'sarahchen',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    bio: 'Digital artist & UI designer creating immersive experiences',
    location: 'San Francisco, CA',
    website: 'sarahchen.design',
    skills: ['UI/UX', 'Illustration', 'Motion Design', 'Figma'],
    followers: 12500,
    following: 342,
    projectsCount: 48,
    isVerified: true
  },
  {
    id: '2',
    name: 'Marcus Johnson',
    username: 'marcusj',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Marcus',
    bio: 'Full-stack developer building the future of web',
    location: 'New York, NY',
    skills: ['React', 'Node.js', 'TypeScript', 'PostgreSQL'],
    followers: 8200,
    following: 156,
    projectsCount: 32,
    isVerified: true
  },
  {
    id: '3',
    name: 'Emma Wilson',
    username: 'emmaw',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emma',
    bio: 'Photographer capturing moments around the world',
    location: 'London, UK',
    website: 'emmawilson.photo',
    skills: ['Photography', 'Lightroom', 'Portrait', 'Landscape'],
    followers: 24100,
    following: 890,
    projectsCount: 156,
    isVerified: false
  },
  {
    id: '4',
    name: 'Alex Rivera',
    username: 'arivera',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex',
    bio: '3D artist and game developer',
    location: 'Austin, TX',
    skills: ['Blender', 'Unity', 'Unreal Engine', 'C#'],
    followers: 5600,
    following: 234,
    projectsCount: 21,
    isVerified: false
  },
  {
    id: '5',
    name: 'Yuki Tanaka',
    username: 'yukit',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Yuki',
    bio: 'Brand designer & creative director',
    location: 'Tokyo, Japan',
    website: 'yukitanaka.jp',
    skills: ['Branding', 'Logo Design', 'Typography', 'Adobe CC'],
    followers: 18900,
    following: 445,
    projectsCount: 67,
    isVerified: true
  }
];

export const mockPortfolioProjects: PortfolioProject[] = [
  {
    id: '1',
    title: 'Neon Dreams',
    description: 'A cyberpunk-inspired digital art series exploring the future of urban life',
    thumbnail: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop',
    creatorId: '1',
    tags: ['Digital Art', 'Cyberpunk', 'Illustration'],
    likes: 2340,
    views: 15600,
    createdAt: '2024-01-15',
    link: 'https://example.com/neon-dreams'
  },
  {
    id: '2',
    title: 'E-Commerce Dashboard',
    description: 'Modern analytics dashboard for online retailers',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop',
    creatorId: '2',
    tags: ['UI/UX', 'Dashboard', 'React'],
    likes: 1890,
    views: 12300,
    createdAt: '2024-02-01'
  },
  {
    id: '3',
    title: 'Mountain Sunrise',
    description: 'Captured at 5 AM in the Swiss Alps',
    thumbnail: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop',
    creatorId: '3',
    tags: ['Photography', 'Landscape', 'Nature'],
    likes: 4560,
    views: 28900,
    createdAt: '2024-01-20'
  },
  {
    id: '4',
    title: 'Low Poly City',
    description: 'Procedurally generated low-poly city environment',
    thumbnail: 'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=400&h=300&fit=crop',
    creatorId: '4',
    tags: ['3D', 'Game Dev', 'Blender'],
    likes: 1230,
    views: 8900,
    createdAt: '2024-02-10'
  },
  {
    id: '5',
    title: 'Zen Brand Identity',
    description: 'Complete brand identity for a wellness startup',
    thumbnail: 'https://images.unsplash.com/photo-1600607686527-6fb886090705?w=400&h=300&fit=crop',
    creatorId: '5',
    tags: ['Branding', 'Identity', 'Logo'],
    likes: 3120,
    views: 19800,
    createdAt: '2024-01-28'
  },
  {
    id: '6',
    title: 'Abstract Flow',
    description: 'Generative art exploring fluid dynamics',
    thumbnail: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=400&h=300&fit=crop',
    creatorId: '1',
    tags: ['Generative Art', 'Abstract', 'Creative Coding'],
    likes: 2780,
    views: 16700,
    createdAt: '2024-02-05'
  }
];

export const portfolioStats = {
  totalCreators: 12450,
  totalProjects: 87600,
  dailyViews: 2340000,
  newSignups: 450
};
