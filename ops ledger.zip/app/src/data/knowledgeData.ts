export interface DocArticle {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  category: string;
  tags: string[];
  author: {
    name: string;
    avatar: string;
  };
  createdAt: string;
  updatedAt: string;
  views: number;
  version: string;
}

export interface DocCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  articleCount: number;
  icon: string;
}

export const mockDocCategories: DocCategory[] = [
  {
    id: '1',
    name: 'Getting Started',
    slug: 'getting-started',
    description: 'Quick start guides and onboarding',
    articleCount: 12,
    icon: 'rocket'
  },
  {
    id: '2',
    name: 'API Reference',
    slug: 'api-reference',
    description: 'Complete API documentation',
    articleCount: 45,
    icon: 'code'
  },
  {
    id: '3',
    name: 'Tutorials',
    slug: 'tutorials',
    description: 'Step-by-step guides and examples',
    articleCount: 28,
    icon: 'book-open'
  },
  {
    id: '4',
    name: 'Best Practices',
    slug: 'best-practices',
    description: 'Recommended patterns and guidelines',
    articleCount: 15,
    icon: 'check-circle'
  },
  {
    id: '5',
    name: 'Troubleshooting',
    slug: 'troubleshooting',
    description: 'Common issues and solutions',
    articleCount: 22,
    icon: 'help-circle'
  },
  {
    id: '6',
    name: 'Changelog',
    slug: 'changelog',
    description: 'Version history and updates',
    articleCount: 8,
    icon: 'git-branch'
  }
];

export const mockDocArticles: DocArticle[] = [
  {
    id: '1',
    title: 'Quick Start Guide',
    slug: 'quick-start',
    excerpt: 'Get up and running in under 5 minutes with our quick start guide.',
    content: `# Quick Start Guide

Welcome to KnowledgeStack! This guide will help you get started in minutes.

## Installation

\`\`\`bash
npm install @knowledgestack/sdk
\`\`\`

## Basic Usage

\`\`\`javascript
import { KnowledgeStack } from '@knowledgestack/sdk';

const ks = new KnowledgeStack({
  apiKey: 'your-api-key'
});

const docs = await ks.docs.list();
\`\`\`

## Next Steps

- Explore the API Reference
- Check out our Tutorials
- Join our community`,
    category: 'getting-started',
    tags: ['beginner', 'setup', 'installation'],
    author: {
      name: 'Alex Chen',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex'
    },
    createdAt: '2024-01-10',
    updatedAt: '2024-02-01',
    views: 15600,
    version: '2.1.0'
  },
  {
    id: '2',
    title: 'Authentication',
    slug: 'authentication',
    excerpt: 'Learn how to authenticate with our API using JWT tokens.',
    content: `# Authentication

KnowledgeStack uses JWT tokens for authentication.

## Getting a Token

\`\`\`bash
curl -X POST https://api.knowledgestack.com/auth/token \\
  -H "Content-Type: application/json" \\
  -d '{
    "client_id": "your-client-id",
    "client_secret": "your-client-secret"
  }'
\`\`\`

## Using the Token

Include the token in your API requests:

\`\`\`bash
curl https://api.knowledgestack.com/docs \\
  -H "Authorization: Bearer YOUR_TOKEN"
\`\`\``,
    category: 'api-reference',
    tags: ['api', 'auth', 'security'],
    author: {
      name: 'Sarah Miller',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah'
    },
    createdAt: '2024-01-15',
    updatedAt: '2024-01-30',
    views: 12300,
    version: '2.0.0'
  },
  {
    id: '3',
    title: 'Building a Documentation Site',
    slug: 'building-docs-site',
    excerpt: 'Step-by-step tutorial on creating your own documentation site.',
    content: `# Building a Documentation Site

This tutorial will walk you through creating a documentation site.

## Prerequisites

- Node.js 18+
- Basic knowledge of React
- A KnowledgeStack account

## Step 1: Create a New Project

\`\`\`bash
npx create-knowledgestack-site my-docs
\`\`\`

## Step 2: Configure Your Site

Edit \`knowledgestack.config.js\`:

\`\`\`javascript
module.exports = {
  title: 'My Documentation',
  description: 'Documentation for my project',
  theme: 'default'
};
\`\`\``,
    category: 'tutorials',
    tags: ['tutorial', 'beginner', 'setup'],
    author: {
      name: 'Marcus Johnson',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Marcus'
    },
    createdAt: '2024-01-20',
    updatedAt: '2024-02-05',
    views: 8900,
    version: '1.5.0'
  },
  {
    id: '4',
    title: 'API Rate Limits',
    slug: 'rate-limits',
    excerpt: 'Understanding API rate limits and how to handle them.',
    content: `# API Rate Limits

To ensure fair usage, KnowledgeStack implements rate limiting.

## Limits

| Plan | Requests/minute | Requests/hour |
|------|----------------|---------------|
| Free | 60 | 1,000 |
| Pro | 300 | 10,000 |
| Enterprise | Unlimited | Unlimited |

## Handling Rate Limits

When you exceed the rate limit, you'll receive a 429 response:

\`\`\`json
{
  "error": "Rate limit exceeded",
  "retry_after": 60
}
\`\`\``,
    category: 'api-reference',
    tags: ['api', 'limits', 'performance'],
    author: {
      name: 'Emily Davis',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emily'
    },
    createdAt: '2024-01-25',
    updatedAt: '2024-02-03',
    views: 6700,
    version: '2.1.0'
  },
  {
    id: '5',
    title: 'Writing Effective Documentation',
    slug: 'writing-effective-docs',
    excerpt: 'Best practices for writing clear and helpful documentation.',
    content: `# Writing Effective Documentation

Good documentation is clear, concise, and helpful.

## Principles

1. **Know your audience** - Write for your users, not yourself
2. **Be concise** - Remove unnecessary words
3. **Use examples** - Show, don't just tell
4. **Keep it updated** - Outdated docs are worse than no docs

## Structure

- Start with a clear title
- Provide a brief overview
- Use headings to organize content
- Include code examples
- Add a summary or next steps`,
    category: 'best-practices',
    tags: ['writing', 'best-practices', 'documentation'],
    author: {
      name: 'Yuki Tanaka',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Yuki'
    },
    createdAt: '2024-02-01',
    updatedAt: '2024-02-06',
    views: 5400,
    version: '1.0.0'
  }
];

export const knowledgeStats = {
  totalArticles: 130,
  totalCategories: 6,
  monthlyViews: 450000,
  contributors: 24
};
