import type { 
  Project, 
  Task, 
  TeamMember, 
  AuditLog, 
  Role, 
  Permission,
  ClientRequest,
  DashboardMetrics,
  User 
} from '@/types';

// Mock Users
export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Alex Chen',
    email: 'admin@opsledger.com',
    role: 'admin',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex',
    department: 'Operations'
  },
  {
    id: '2',
    name: 'Sarah Miller',
    email: 'staff@opsledger.com',
    role: 'staff',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    department: 'Project Management'
  },
  {
    id: '3',
    name: 'James Wilson',
    email: 'client@opsledger.com',
    role: 'client',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=James',
    department: 'External'
  },
  {
    id: '4',
    name: 'Emily Davis',
    email: 'emily@opsledger.com',
    role: 'staff',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emily',
    department: 'Engineering'
  },
  {
    id: '5',
    name: 'Michael Brown',
    email: 'michael@opsledger.com',
    role: 'staff',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Michael',
    department: 'Design'
  },
  {
    id: '6',
    name: 'Lisa Anderson',
    email: 'lisa@client.com',
    role: 'client',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lisa',
    department: 'External'
  }
];

// Mock Projects
export const mockProjects: Project[] = [
  {
    id: '1',
    name: 'Platform Migration',
    description: 'Migrate legacy systems to new cloud infrastructure',
    status: 'active',
    progress: 65,
    owner: mockUsers[0],
    startDate: '2024-01-15',
    dueDate: '2024-06-30',
    team: [mockUsers[0], mockUsers[1], mockUsers[3]],
    tasksCount: 24,
    completedTasks: 16,
    client: mockUsers[2]
  },
  {
    id: '2',
    name: 'Client Portal Redesign',
    description: 'Modernize the client-facing dashboard with improved UX',
    status: 'active',
    progress: 40,
    owner: mockUsers[1],
    startDate: '2024-02-01',
    dueDate: '2024-05-15',
    team: [mockUsers[1], mockUsers[4]],
    tasksCount: 18,
    completedTasks: 7,
    client: mockUsers[5]
  },
  {
    id: '3',
    name: 'Security Audit 2024',
    description: 'Comprehensive security review and compliance update',
    status: 'completed',
    progress: 100,
    owner: mockUsers[0],
    startDate: '2024-01-01',
    dueDate: '2024-02-28',
    team: [mockUsers[0], mockUsers[3]],
    tasksCount: 12,
    completedTasks: 12
  },
  {
    id: '4',
    name: 'API Integration',
    description: 'Integrate third-party APIs for enhanced functionality',
    status: 'on_hold',
    progress: 25,
    owner: mockUsers[3],
    startDate: '2024-03-01',
    dueDate: '2024-07-31',
    team: [mockUsers[3]],
    tasksCount: 15,
    completedTasks: 4,
    client: mockUsers[2]
  },
  {
    id: '5',
    name: 'Documentation Update',
    description: 'Update all technical and user documentation',
    status: 'active',
    progress: 80,
    owner: mockUsers[1],
    startDate: '2024-02-15',
    dueDate: '2024-04-30',
    team: [mockUsers[1], mockUsers[4]],
    tasksCount: 10,
    completedTasks: 8
  }
];

// Mock Tasks
export const mockTasks: Task[] = [
  {
    id: '1',
    title: 'Database Schema Design',
    description: 'Design the new database schema for the migration project',
    status: 'done',
    priority: 'high',
    assignee: mockUsers[3],
    project: mockProjects[0],
    dueDate: '2024-02-15',
    createdAt: '2024-01-20',
    checklist: [
      { id: '1', text: 'Analyze current schema', completed: true },
      { id: '2', text: 'Design new schema', completed: true },
      { id: '3', text: 'Review with team', completed: true }
    ],
    comments: [
      { id: '1', author: mockUsers[0], content: 'Looks good, approved!', createdAt: '2024-02-14' }
    ]
  },
  {
    id: '2',
    title: 'User Interface Mockups',
    description: 'Create mockups for the new client portal design',
    status: 'in_progress',
    priority: 'medium',
    assignee: mockUsers[4],
    project: mockProjects[1],
    dueDate: '2024-03-15',
    createdAt: '2024-02-10',
    checklist: [
      { id: '1', text: 'Research competitors', completed: true },
      { id: '2', text: 'Create wireframes', completed: true },
      { id: '3', text: 'Design high-fidelity mockups', completed: false }
    ],
    comments: []
  },
  {
    id: '3',
    title: 'Security Vulnerability Assessment',
    description: 'Conduct vulnerability assessment for all systems',
    status: 'done',
    priority: 'urgent',
    assignee: mockUsers[0],
    project: mockProjects[2],
    dueDate: '2024-02-20',
    createdAt: '2024-01-25',
    checklist: [
      { id: '1', text: 'Run automated scans', completed: true },
      { id: '2', text: 'Manual penetration testing', completed: true },
      { id: '3', text: 'Generate report', completed: true }
    ],
    comments: [
      { id: '1', author: mockUsers[1], content: 'Great work on finding those issues!', createdAt: '2024-02-21' }
    ]
  },
  {
    id: '4',
    title: 'API Documentation',
    description: 'Document all API endpoints and usage examples',
    status: 'in_progress',
    priority: 'medium',
    assignee: mockUsers[3],
    project: mockProjects[4],
    dueDate: '2024-04-15',
    createdAt: '2024-02-20',
    checklist: [
      { id: '1', text: 'Document authentication', completed: true },
      { id: '2', text: 'Document endpoints', completed: false },
      { id: '3', text: 'Add code examples', completed: false }
    ],
    comments: []
  },
  {
    id: '5',
    title: 'Client Feedback Integration',
    description: 'Integrate client feedback into the portal redesign',
    status: 'todo',
    priority: 'high',
    assignee: mockUsers[4],
    project: mockProjects[1],
    dueDate: '2024-04-01',
    createdAt: '2024-03-01',
    checklist: [
      { id: '1', text: 'Review feedback', completed: false },
      { id: '2', text: 'Prioritize changes', completed: false },
      { id: '3', text: 'Implement updates', completed: false }
    ],
    comments: []
  },
  {
    id: '6',
    title: 'Performance Optimization',
    description: 'Optimize database queries and API response times',
    status: 'review',
    priority: 'high',
    assignee: mockUsers[3],
    project: mockProjects[0],
    dueDate: '2024-03-30',
    createdAt: '2024-02-25',
    checklist: [
      { id: '1', text: 'Identify slow queries', completed: true },
      { id: '2', text: 'Add indexes', completed: true },
      { id: '3', text: 'Test performance', completed: true }
    ],
    comments: [
      { id: '1', author: mockUsers[0], content: 'Please review the test results', createdAt: '2024-03-28' }
    ]
  }
];

// Mock Team Members with Workload
export const mockTeamMembers: TeamMember[] = [
  {
    id: '1',
    user: mockUsers[0],
    activeTasks: 3,
    completedTasks: 45,
    workload: 75,
    availability: 'busy'
  },
  {
    id: '2',
    user: mockUsers[1],
    activeTasks: 5,
    completedTasks: 38,
    workload: 85,
    availability: 'busy'
  },
  {
    id: '3',
    user: mockUsers[3],
    activeTasks: 4,
    completedTasks: 52,
    workload: 70,
    availability: 'available'
  },
  {
    id: '4',
    user: mockUsers[4],
    activeTasks: 3,
    completedTasks: 31,
    workload: 60,
    availability: 'available'
  }
];

// Mock Permissions
export const mockPermissions: Permission[] = [
  { id: '1', name: 'projects.view', description: 'View projects', category: 'projects' },
  { id: '2', name: 'projects.create', description: 'Create projects', category: 'projects' },
  { id: '3', name: 'projects.edit', description: 'Edit projects', category: 'projects' },
  { id: '4', name: 'projects.delete', description: 'Delete projects', category: 'projects' },
  { id: '5', name: 'tasks.view', description: 'View tasks', category: 'tasks' },
  { id: '6', name: 'tasks.create', description: 'Create tasks', category: 'tasks' },
  { id: '7', name: 'tasks.edit', description: 'Edit tasks', category: 'tasks' },
  { id: '8', name: 'tasks.delete', description: 'Delete tasks', category: 'tasks' },
  { id: '9', name: 'users.view', description: 'View users', category: 'users' },
  { id: '10', name: 'users.manage', description: 'Manage users', category: 'users' },
  { id: '11', name: 'audit.view', description: 'View audit logs', category: 'audit' },
  { id: '12', name: 'settings.manage', description: 'Manage settings', category: 'settings' }
];

// Mock Roles
export const mockRoles: Role[] = [
  {
    id: '1',
    name: 'Administrator',
    description: 'Full access to all features and settings',
    permissions: mockPermissions,
    userCount: 1
  },
  {
    id: '2',
    name: 'Manager',
    description: 'Can manage projects, tasks, and team members',
    permissions: mockPermissions.filter(p => 
      ['projects.view', 'projects.create', 'projects.edit', 
       'tasks.view', 'tasks.create', 'tasks.edit', 'tasks.delete',
       'users.view'].includes(p.name)
    ),
    userCount: 2
  },
  {
    id: '3',
    name: 'Team Member',
    description: 'Can view and work on assigned tasks',
    permissions: mockPermissions.filter(p => 
      ['projects.view', 'tasks.view', 'tasks.create', 'tasks.edit'].includes(p.name)
    ),
    userCount: 2
  },
  {
    id: '4',
    name: 'Client',
    description: 'Limited access to view own projects and requests',
    permissions: mockPermissions.filter(p => 
      ['projects.view', 'tasks.view'].includes(p.name)
    ),
    userCount: 2
  }
];

// Mock Audit Logs
export const mockAuditLogs: AuditLog[] = [
  {
    id: '1',
    timestamp: '2024-03-15T10:30:00Z',
    user: mockUsers[0],
    action: 'created',
    entityType: 'project',
    entityId: '1',
    entityName: 'Platform Migration',
    details: 'Created new project with team members',
    ipAddress: '192.168.1.100'
  },
  {
    id: '2',
    timestamp: '2024-03-15T11:45:00Z',
    user: mockUsers[1],
    action: 'updated',
    entityType: 'task',
    entityId: '2',
    entityName: 'User Interface Mockups',
    details: 'Changed status from "todo" to "in_progress"',
    ipAddress: '192.168.1.101'
  },
  {
    id: '3',
    timestamp: '2024-03-15T14:20:00Z',
    user: mockUsers[3],
    action: 'status_changed',
    entityType: 'task',
    entityId: '6',
    entityName: 'Performance Optimization',
    details: 'Changed status from "in_progress" to "review"',
    ipAddress: '192.168.1.102'
  },
  {
    id: '4',
    timestamp: '2024-03-15T16:00:00Z',
    user: mockUsers[0],
    action: 'viewed',
    entityType: 'audit',
    entityId: 'all',
    entityName: 'Audit Logs',
    details: 'Viewed audit log page',
    ipAddress: '192.168.1.100'
  },
  {
    id: '5',
    timestamp: '2024-03-14T09:15:00Z',
    user: mockUsers[2],
    action: 'created',
    entityType: 'task',
    entityId: '5',
    entityName: 'Client Feedback Integration',
    details: 'Submitted new task request',
    ipAddress: '203.45.67.89'
  }
];

// Mock Client Requests
export const mockClientRequests: ClientRequest[] = [
  {
    id: '1',
    title: 'Add Export Feature',
    description: 'We need the ability to export reports as PDF',
    status: 'in_progress',
    priority: 'high',
    client: mockUsers[2],
    submittedAt: '2024-03-10',
    assignedTo: mockUsers[3]
  },
  {
    id: '2',
    title: 'Update Brand Colors',
    description: 'Please update the portal with our new brand colors',
    status: 'completed',
    priority: 'medium',
    client: mockUsers[5],
    submittedAt: '2024-03-05',
    completedAt: '2024-03-12',
    assignedTo: mockUsers[4]
  },
  {
    id: '3',
    title: 'Mobile Responsiveness',
    description: 'The dashboard doesn\'t work well on mobile devices',
    status: 'pending',
    priority: 'high',
    client: mockUsers[2],
    submittedAt: '2024-03-14'
  },
  {
    id: '4',
    title: 'Add Notification Emails',
    description: 'We want email notifications when tasks are completed',
    status: 'in_progress',
    priority: 'medium',
    client: mockUsers[5],
    submittedAt: '2024-03-08',
    assignedTo: mockUsers[3]
  }
];

// Mock Dashboard Metrics
export const mockDashboardMetrics: DashboardMetrics = {
  totalProjects: 5,
  activeProjects: 3,
  completedProjects: 1,
  totalTasks: 79,
  pendingTasks: 12,
  inProgressTasks: 18,
  completedTasks: 45,
  overdueTasks: 4,
  teamMembers: 4,
  activeClients: 2,
  averageCompletionTime: 5.2
};

// Helper functions
export const getProjectsByStatus = (status: Project['status']) => 
  mockProjects.filter(p => p.status === status);

export const getTasksByStatus = (status: Task['status']) => 
  mockTasks.filter(t => t.status === status);

export const getTasksByAssignee = (userId: string) => 
  mockTasks.filter(t => t.assignee.id === userId);

export const getRecentAuditLogs = (limit: number = 10) => 
  mockAuditLogs.slice(0, limit);

export const getClientRequestsByStatus = (status: ClientRequest['status']) =>
  mockClientRequests.filter(r => r.status === status);
