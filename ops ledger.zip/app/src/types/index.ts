import type { UserRole } from '@/contexts/AuthContext';

// Project Types
export interface Project {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'completed' | 'on_hold' | 'cancelled';
  progress: number;
  owner: User;
  startDate: string;
  dueDate: string;
  team: User[];
  tasksCount: number;
  completedTasks: number;
  client?: User;
}

// Task Types
export interface Task {
  id: string;
  title: string;
  description: string;
  status: 'todo' | 'in_progress' | 'review' | 'done';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignee: User;
  project: Project;
  dueDate: string;
  createdAt: string;
  checklist: ChecklistItem[];
  comments: Comment[];
}

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface Comment {
  id: string;
  author: User;
  content: string;
  createdAt: string;
}

// Workload Types
export interface TeamMember {
  id: string;
  user: User;
  activeTasks: number;
  completedTasks: number;
  workload: number; // 0-100
  availability: 'available' | 'busy' | 'overloaded' | 'away';
}

// Audit Log Types
export interface AuditLog {
  id: string;
  timestamp: string;
  user: User;
  action: 'created' | 'updated' | 'deleted' | 'viewed' | 'assigned' | 'status_changed';
  entityType: 'project' | 'task' | 'user' | 'role' | 'setting' | 'audit';
  entityId: string;
  entityName: string;
  details: string;
  ipAddress: string;
}

// Role & Permission Types
export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  userCount: number;
}

export interface Permission {
  id: string;
  name: string;
  description: string;
  category: 'projects' | 'tasks' | 'users' | 'audit' | 'settings';
}

// Client Portal Types
export interface ClientRequest {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'rejected';
  priority: 'low' | 'medium' | 'high';
  client: User;
  submittedAt: string;
  completedAt?: string;
  assignedTo?: User;
}

// Dashboard Metrics
export interface DashboardMetrics {
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  totalTasks: number;
  pendingTasks: number;
  inProgressTasks: number;
  completedTasks: number;
  overdueTasks: number;
  teamMembers: number;
  activeClients: number;
  averageCompletionTime: number; // in days
}

// User (extended from AuthContext)
export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  department?: string;
}

// Theme Settings
export interface ThemeSettings {
  primaryColor: string;
  accentColor: string;
  bgColor: string;
  textColor: string;
}

// Navigation Types
export interface NavItem {
  id: string;
  label: string;
  icon: string;
  path: string;
  requiredRoles: UserRole[];
  badge?: number;
}
