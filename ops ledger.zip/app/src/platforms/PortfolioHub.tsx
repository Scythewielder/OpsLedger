import { useState } from 'react';
import { useEditableData } from '@/contexts/EditableDataContext';
import { useLayout } from '@/contexts/LayoutContext';
import { mockCreators, mockPortfolioProjects, portfolioStats } from '@/data/portfolioData';
import { 
  Search, 
  Heart, 
  Eye, 
  ExternalLink, 
  MapPin, 
  Link as LinkIcon,
  Users,
  Folder,
  Grid3X3,
  List,
  Edit2,
  Save,
  X
} from 'lucide-react';

export function PortfolioHub() {
  const [activeTab, setActiveTab] = useState<'discover' | 'creators' | 'trending'>('discover');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSkill, setSelectedSkill] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [editingProfile, setEditingProfile] = useState(false);
  const { currentUser, updateCurrentUser } = useEditableData();
  const { sidebarCollapsed } = useLayout();

  const [editForm, setEditForm] = useState({
    name: currentUser?.name || '',
    bio: 'Digital creator & designer',
    location: 'San Francisco, CA',
    website: 'portfolio.me'
  });

  const allSkills = Array.from(new Set(mockCreators.flatMap(c => c.skills)));

  const filteredProjects = mockPortfolioProjects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSkill = selectedSkill === 'all' || project.tags.includes(selectedSkill);
    return matchesSearch && matchesSkill;
  });

  const handleSaveProfile = () => {
    updateCurrentUser({ name: editForm.name });
    setEditingProfile(false);
  };

  return (
    <div 
      className="min-h-screen bg-gray-50 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Folder className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">PortfolioHub</h1>
                <p className="text-xs text-gray-500">Creator Platform</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              {/* Stats */}
              <div className="hidden md:flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">{portfolioStats.totalCreators.toLocaleString()} creators</span>
                </div>
                <div className="flex items-center gap-2">
                  <Folder className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">{portfolioStats.totalProjects.toLocaleString()} projects</span>
                </div>
              </div>
              
              {/* Profile */}
              <div className="flex items-center gap-3">
                <img
                  src={currentUser?.avatar}
                  alt={currentUser?.name}
                  className="w-9 h-9 rounded-full bg-gray-100"
                />
              </div>
            </div>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="px-6 flex gap-1">
          {[
            { id: 'discover', label: 'Discover', count: null },
            { id: 'creators', label: 'Creators', count: mockCreators.length },
            { id: 'trending', label: 'Trending', count: null }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`px-4 py-3 text-sm font-medium transition-colors relative ${
                activeTab === tab.id 
                  ? 'text-indigo-600' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.label}
              {tab.count && <span className="ml-1 text-xs text-gray-400">({tab.count})</span>}
              {activeTab === tab.id && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
              )}
            </button>
          ))}
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search projects, creators, skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-white border border-gray-200 text-gray-900 placeholder-gray-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none"
            />
          </div>
          
          <div className="flex gap-3">
            <select
              value={selectedSkill}
              onChange={(e) => setSelectedSkill(e.target.value)}
              className="px-4 py-3 rounded-xl bg-white border border-gray-200 text-gray-700 focus:border-indigo-500 outline-none"
            >
              <option value="all">All Skills</option>
              {allSkills.map(skill => (
                <option key={skill} value={skill}>{skill}</option>
              ))}
            </select>
            
            <div className="flex bg-white rounded-xl border border-gray-200 p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-indigo-100 text-indigo-600' : 'text-gray-400'}`}
              >
                <Grid3X3 className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-indigo-100 text-indigo-600' : 'text-gray-400'}`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Creator Profile Card (Editable) */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6 mb-8">
          <div className="flex items-start justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Your Profile</h3>
            {!editingProfile ? (
              <button
                onClick={() => setEditingProfile(true)}
                className="flex items-center gap-2 px-3 py-1.5 text-sm text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
              >
                <Edit2 className="w-4 h-4" />
                Edit
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={handleSaveProfile}
                  className="flex items-center gap-2 px-3 py-1.5 text-sm text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
                >
                  <Save className="w-4 h-4" />
                  Save
                </button>
                <button
                  onClick={() => setEditingProfile(false)}
                  className="flex items-center gap-2 px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                  Cancel
                </button>
              </div>
            )}
          </div>
          
          <div className="flex items-start gap-6">
            <img
              src={currentUser?.avatar}
              alt={currentUser?.name}
              className="w-20 h-20 rounded-2xl bg-gray-100"
            />
            <div className="flex-1">
              {editingProfile ? (
                <div className="space-y-3">
                  <input
                    type="text"
                    value={editForm.name}
                    onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 outline-none"
                    placeholder="Your name"
                  />
                  <input
                    type="text"
                    value={editForm.bio}
                    onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 outline-none"
                    placeholder="Bio"
                  />
                  <div className="flex gap-3">
                    <input
                      type="text"
                      value={editForm.location}
                      onChange={(e) => setEditForm({...editForm, location: e.target.value})}
                      className="flex-1 px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 outline-none"
                      placeholder="Location"
                    />
                    <input
                      type="text"
                      value={editForm.website}
                      onChange={(e) => setEditForm({...editForm, website: e.target.value})}
                      className="flex-1 px-3 py-2 rounded-lg border border-gray-200 focus:border-indigo-500 outline-none"
                      placeholder="Website"
                    />
                  </div>
                </div>
              ) : (
                <>
                  <h2 className="text-2xl font-bold text-gray-900">{currentUser?.name}</h2>
                  <p className="text-gray-500 mt-1">@{currentUser?.email?.split('@')[0]}</p>
                  <p className="text-gray-600 mt-2">{editForm.bio}</p>
                  <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {editForm.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <LinkIcon className="w-4 h-4" />
                      {editForm.website}
                    </span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Projects Grid */}
        <div className={viewMode === 'grid' 
          ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
          : 'flex flex-col gap-4'
        }>
          {filteredProjects.map((project) => (
            <div 
              key={project.id} 
              className={`bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow ${
                viewMode === 'list' ? 'flex' : ''
              }`}
            >
              <div className={`${viewMode === 'list' ? 'w-48' : 'h-48'} bg-gray-100 relative overflow-hidden`}>
                <img
                  src={project.thumbnail}
                  alt={project.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-5 flex-1">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-900">{project.title}</h3>
                  {project.link && (
                    <a 
                      href={project.link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-indigo-600"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>
                <p className="text-sm text-gray-500 line-clamp-2 mb-3">{project.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map(tag => (
                    <span key={tag} className="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
                
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      {project.likes.toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {project.views.toLocaleString()}
                    </span>
                  </div>
                  <span className="text-xs">{new Date(project.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredProjects.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="font-medium text-gray-900 mb-1">No projects found</h3>
            <p className="text-gray-500">Try adjusting your search or filters</p>
          </div>
        )}
      </main>
    </div>
  );
}
