import { useState } from 'react';

import { useLayout } from '@/contexts/LayoutContext';
import { mockDocCategories, mockDocArticles, knowledgeStats } from '@/data/knowledgeData';
import { 
  Search, 
  BookOpen, 
  Code, 
  Rocket, 
  CheckCircle, 
  HelpCircle, 
  GitBranch,
  Clock,
  Eye,
  User,
  ChevronRight,
  Edit2,
  Save,
  X,
  Hash,
  ArrowLeft
} from 'lucide-react';

const categoryIcons: Record<string, React.ReactNode> = {
  'rocket': <Rocket className="w-5 h-5" />,
  'code': <Code className="w-5 h-5" />,
  'book-open': <BookOpen className="w-5 h-5" />,
  'check-circle': <CheckCircle className="w-5 h-5" />,
  'help-circle': <HelpCircle className="w-5 h-5" />,
  'git-branch': <GitBranch className="w-5 h-5" />
};

export function KnowledgeStack() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<typeof mockDocArticles[0] | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingArticle, setEditingArticle] = useState(false);
  const [editContent, setEditContent] = useState('');
  const { sidebarCollapsed } = useLayout();

  const filteredArticles = mockDocArticles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleEditArticle = () => {
    if (selectedArticle) {
      setEditContent(selectedArticle.content);
      setEditingArticle(true);
    }
  };

  const handleSaveArticle = () => {
    // In a real app, this would save to the backend
    setEditingArticle(false);
  };

  // Article View
  if (selectedArticle) {
    return (
      <div 
        className="min-h-screen bg-white transition-all duration-300"
        style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
      >
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setSelectedArticle(null)}
                className="flex items-center gap-2 text-gray-500 hover:text-gray-700"
              >
                <ArrowLeft className="w-5 h-5" />
                Back to docs
              </button>
              
              <div className="flex items-center gap-3">
                {!editingArticle ? (
                  <button
                    onClick={handleEditArticle}
                    className="flex items-center gap-2 px-4 py-2 text-sm text-teal-600 hover:bg-teal-50 rounded-lg transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                    Edit
                  </button>
                ) : (
                  <div className="flex gap-2">
                    <button
                      onClick={handleSaveArticle}
                      className="flex items-center gap-2 px-4 py-2 text-sm text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors"
                    >
                      <Save className="w-4 h-4" />
                      Save
                    </button>
                    <button
                      onClick={() => setEditingArticle(false)}
                      className="flex items-center gap-2 px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <X className="w-4 h-4" />
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Article Content */}
        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="mb-8">
            <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
              <span className="px-2 py-1 bg-gray-100 rounded">{selectedArticle.category}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {new Date(selectedArticle.updatedAt).toLocaleDateString()}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                {selectedArticle.views.toLocaleString()} views
              </span>
            </div>
            
            <h1 className="text-4xl font-bold text-gray-900 mb-4">{selectedArticle.title}</h1>
            <p className="text-xl text-gray-600">{selectedArticle.excerpt}</p>
            
            <div className="flex items-center gap-3 mt-6">
              <img
                src={selectedArticle.author.avatar}
                alt={selectedArticle.author.name}
                className="w-10 h-10 rounded-full bg-gray-100"
              />
              <div>
                <p className="font-medium text-gray-900">{selectedArticle.author.name}</p>
                <p className="text-sm text-gray-500">Author</p>
              </div>
            </div>
          </div>

          {editingArticle ? (
            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              className="w-full h-96 p-4 font-mono text-sm bg-gray-50 border border-gray-200 rounded-xl focus:border-teal-500 outline-none resize-none"
            />
          ) : (
            <div className="prose prose-lg max-w-none">
              <div className="bg-gray-50 rounded-xl p-6 font-mono text-sm whitespace-pre-wrap">
                {selectedArticle.content}
              </div>
            </div>
          )}

          {/* Tags */}
          <div className="mt-8 pt-8 border-t border-gray-200">
            <div className="flex items-center gap-2 flex-wrap">
              <Hash className="w-4 h-4 text-gray-400" />
              {selectedArticle.tags.map(tag => (
                <span key={tag} className="px-3 py-1 text-sm bg-gray-100 text-gray-600 rounded-full">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Main Docs View
  return (
    <div 
      className="min-h-screen bg-gray-50 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">KnowledgeStack</h1>
                <p className="text-xs text-gray-500">Documentation Platform</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-gray-400" />
                <span className="text-gray-600">{knowledgeStats.totalArticles} articles</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-gray-400" />
                <span className="text-gray-600">{knowledgeStats.monthlyViews.toLocaleString()} monthly views</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        {/* Search */}
        <div className="max-w-2xl mx-auto mb-10">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search documentation..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-xl bg-white border border-gray-200 text-gray-900 placeholder-gray-400 focus:border-teal-500 focus:ring-2 focus:ring-teal-100 outline-none text-lg"
            />
          </div>
        </div>

        {/* Categories */}
        {!searchQuery && !selectedCategory && (
          <div className="mb-10">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Browse by Category</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockDocCategories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.slug)}
                  className="flex items-start gap-4 p-5 bg-white rounded-xl border border-gray-200 hover:border-teal-500 hover:shadow-md transition-all text-left"
                >
                  <div className="w-10 h-10 rounded-lg bg-teal-50 text-teal-600 flex items-center justify-center flex-shrink-0">
                    {categoryIcons[category.icon]}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{category.name}</h3>
                    <p className="text-sm text-gray-500 mt-1">{category.description}</p>
                    <p className="text-xs text-gray-400 mt-2">{category.articleCount} articles</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Articles List */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              {selectedCategory 
                ? mockDocCategories.find(c => c.slug === selectedCategory)?.name 
                : searchQuery 
                  ? 'Search Results' 
                  : 'All Articles'}
            </h2>
            {selectedCategory && (
              <button
                onClick={() => setSelectedCategory(null)}
                className="text-sm text-teal-600 hover:text-teal-700"
              >
                Clear filter
              </button>
            )}
          </div>
          
          <div className="space-y-3">
            {filteredArticles.map((article) => (
              <button
                key={article.id}
                onClick={() => setSelectedArticle(article)}
                className="w-full flex items-start gap-4 p-5 bg-white rounded-xl border border-gray-200 hover:border-teal-500 hover:shadow-md transition-all text-left"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 text-xs bg-gray-100 text-gray-600 rounded">
                      {article.category}
                    </span>
                    <span className="text-xs text-gray-400">v{article.version}</span>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">{article.title}</h3>
                  <p className="text-sm text-gray-500">{article.excerpt}</p>
                  <div className="flex items-center gap-4 mt-3 text-xs text-gray-400">
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {article.author.name}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(article.updatedAt).toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {article.views.toLocaleString()}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-300 flex-shrink-0" />
              </button>
            ))}
          </div>

          {filteredArticles.length === 0 && (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="font-medium text-gray-900 mb-1">No articles found</h3>
              <p className="text-gray-500">Try adjusting your search</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
